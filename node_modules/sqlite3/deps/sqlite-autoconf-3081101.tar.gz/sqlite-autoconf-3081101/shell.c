/*
** 2001 September 15
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This file contains code to implement the "sqlite" command line
** utility for accessing SQLite databases.
*/
#if (defined(_WIN32) || defined(WIN32)) && !defined(_CRT_SECURE_NO_WARNINGS)
/* This needs to come before any includes for MSVC compiler */
#define _CRT_SECURE_NO_WARNINGS
#endif

/*
** If requested, include the SQLite compiler options file for MSVC.
*/
#if defined(INCLUDE_MSVC_H)
#include "msvc.h"
#endif

/*
** No support for loadable extensions in VxWorks.
*/
#if (defined(__RTP__) || defined(_WRS_KERNEL)) && !SQLITE_OMIT_LOAD_EXTENSION
# define SQLITE_OMIT_LOAD_EXTENSION 1
#endif

/*
** Enable large-file support for fopen() and friends on unix.
*/
#ifndef SQLITE_DISABLE_LFS
# define _LARGE_FILE       1
# ifndef _FILE_OFFSET_BITS
#   define _FILE_OFFSET_BITS 64
# endif
# define _LARGEFILE_SOURCE 1
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "sqlite3.h"
#if SQLITE_USER_AUTHENTICATION
# include "sqlite3userauth.h"
#endif
#include <ctype.h>
#include <stdarg.h>

#if !defined(_WIN32) && !defined(WIN32)
# include <signal.h>
# if !defined(__RTP__) && !defined(_WRS_KERNEL)
#  include <pwd.h>
# endif
# include <unistd.h>
# include <sys/types.h>
#endif

#if HAVE_READLINE
# include <readline/readline.h>
# include <readline/history.h>
#endif

#if HAVE_EDITLINE
# include <editline/readline.h>
#endif

#if HAVE_EDITLINE || HAVE_READLINE

# define shell_add_history(X) add_history(X)
# define shell_read_history(X) read_history(X)
# define shell_write_history(X) write_history(X)
# define shell_stifle_history(X) stifle_history(X)
# define shell_readline(X) readline(X)

#elif HAVE_LINENOISE

# include "linenoise.h"
# define shell_add_history(X) linenoiseHistoryAdd(X)
# define shell_read_history(X) linenoiseHistoryLoad(X)
# define shell_write_history(X) linenoiseHistorySave(X)
# define shell_stifle_history(X) linenoiseHistorySetMaxLen(X)
# define shell_readline(X) linenoise(X)

#else

# define shell_read_history(X) 
# define shell_write_history(X)
# define shell_stifle_history(X)

# define SHELL_USE_LOCAL_GETLINE 1
#endif


#if defined(_WIN32) || defined(WIN32)
# include <io.h>
# include <fcntl.h>
# define isatty(h) _isatty(h)
# ifndef access
#  define access(f,m) _access((f),(m))
# endif
# undef popen
# define popen _popen
# undef pclose
# define pclose _pclose
#else
 /* Make sure isatty() has a prototype. */
 extern int isatty(int);

# if !defined(__RTP__) && !defined(_WRS_KERNEL)
  /* popen and pclose are not C89 functions and so are
  ** sometimes omitted from the <stdio.h> header */
   extern FILE *popen(const char*,const char*);
   extern int pclose(FILE*);
# else
#  define SQLITE_OMIT_POPEN 1
# endif
#endif

#if defined(_WIN32_WCE)
/* Windows CE (arm-wince-mingw32ce-gcc) does not provide isatty()
 * thus we always assume that we have a console. That can be
 * overridden with the -batch command line option.
 */
#define isatty(x) 1
#endif

/* ctype macros that work with signed characters */
#define IsSpace(X)  isspace((unsigned char)X)
#define IsDigit(X)  isdigit((unsigned char)X)
#define ToLower(X)  (char)tolower((unsigned char)X)

/* On Windows, we normally run with output mode of TEXT so that \n characters
** are automatically translated into \r\n.  However, this behavior needs
** to be disabled in some cases (ex: when generating CSV output and when
** rendering quoted strings that contain \n characters).  The following
** routines take care of that.
*/
#if defined(_WIN32) || defined(WIN32)
static void setBinaryMode(FILE *out){
  fflush(out);
  _setmode(_fileno(out), _O_BINARY);
}
static void setTextMode(FILE *out){
  fflush(out);
  _setmode(_fileno(out), _O_TEXT);
}
#else
# define setBinaryMode(X)
# define setTextMode(X)
#endif


/* True if the timer is enabled */
static int enableTimer = 0;

/* Return the current wall-clock time */
static sqlite3_int64 timeOfDay(void){
  static sqlite3_vfs *clockVfs = 0;
  sqlite3_int64 t;
  if( clockVfs==0 ) clockVfs = sqlite3_vfs_find(0);
  if( clockVfs->iVersion>=1 && clockVfs->xCurrentTimeInt64!=0 ){
    clockVfs->xCurrentTimeInt64(clockVfs, &t);
  }else{
    double r;
    clockVfs->xCurrentTime(clockVfs, &r);
    t = (sqlite3_int64)(r*86400000.0);
  }
  return t;
}

#if !defined(_WIN32) && !defined(WIN32) && !defined(__minux)
#include <sys/time.h>
#include <sys/resource.h>

/* VxWorks does not support getrusage() as far as we can determine */
#if defined(_WRS_KERNEL) || defined(__RTP__)
struct rusage {
  struct timeval ru_utime; /* user CPU time used */
  struct timeval ru_stime; /* system CPU time used */
};
#define getrusage(A,B) memset(B,0,sizeof(*B))
#endif

/* Saved resource information for the beginning of an operation */
static struct rusage sBegin;  /* CPU time at start */
static sqlite3_int64 iBegin;  /* Wall-clock time at start */

/*
** Begin timing an operation
*/
static void beginTimer(void){
  if( enableTimer ){
    getrusage(RUSAGE_SELF, &sBegin);
    iBegin = timeOfDay();
  }
}

/* Return the difference of two time_structs in seconds */
static double timeDiff(struct timeval *pStart, struct timeval *pEnd){
  return (pEnd->tv_usec - pStart->tv_usec)*0.000001 + 
         (double)(pEnd->tv_sec - pStart->tv_sec);
}

/*
** Print the timing results.
*/
static void endTimer(void){
  if( enableTimer ){
    sqlite3_int64 iEnd = timeOfDay();
    struct rusage sEnd;
    getrusage(RUSAGE_SELF, &sEnd);
    printf("Run Time: real %.3f user %f sys %f\n",
       (iEnd - iBegin)*0.001,
       timeDiff(&sBegin.ru_utime, &sEnd.ru_utime),
       timeDiff(&sBegin.ru_stime, &sEnd.ru_stime));
  }
}

#define BEGIN_TIMER beginTimer()
#define END_TIMER endTimer()
#define HAS_TIMER 1

#elif (defined(_WIN32) || defined(WIN32))

#include <windows.h>

/* Saved resource information for the beginning of an operation */
static HANDLE hProcess;
static FILETIME ftKernelBegin;
static FILETIME ftUserBegin;
static sqlite3_int64 ftWallBegin;
typedef BOOL (WINAPI *GETPROCTIMES)(HANDLE, LPFILETIME, LPFILETIME,
                                    LPFILETIME, LPFILETIME);
static GETPROCTIMES getProcessTimesAddr = NULL;

/*
** Check to see if we have timer support.  Return 1 if necessary
** support found (or found previously).
*/
static int hasTimer(void){
  if( getProcessTimesAddr ){
    return 1;
  } else {
    /* GetProcessTimes() isn't supported in WIN95 and some other Windows
    ** versions. See if the version we are running on has it, and if it
    ** does, save off a pointer to it and the current process handle.
    */
    hProcess = GetCurrentProcess();
    if( hProcess ){
      HINSTANCE hinstLib = LoadLibrary(TEXT("Kernel32.dll"));
      if( NULL != hinstLib ){
        getProcessTimesAddr =
            (GETPROCTIMES) GetProcAddress(hinstLib, "GetProcessTimes");
        if( NULL != getProcessTimesAddr ){
          return 1;
        }
        FreeLibrary(hinstLib); 
      }
    }
  }
  return 0;
}

/*
** Begin timing an operation
*/
static void beginTimer(void){
  if( enableTimer && getProcessTimesAddr ){
    FILETIME ftCreation, ftExit;
    getProcessTimesAddr(hProcess,&ftCreation,&ftExit,
                        &ftKernelBegin,&ftUserBegin);
    ftWallBegin = timeOfDay();
  }
}

/* Return the difference of two FILETIME structs in seconds */
static double timeDiff(FILETIME *pStart, FILETIME *pEnd){
  sqlite_int64 i64Start = *((sqlite_int64 *) pStart);
  sqlite_int64 i64End = *((sqlite_int64 *) pEnd);
  return (double) ((i64End - i64Start) / 10000000.0);
}

/*
** Print the timing results.
*/
static void endTimer(void){
  if( enableTimer && getProcessTimesAddr){
    FILETIME ftCreation, ftExit, ftKernelEnd, ftUserEnd;
    sqlite3_int64 ftWallEnd = timeOfDay();
    getProcessTimesAddr(hProcess,&ftCreation,&ftExit,&ftKernelEnd,&ftUserEnd);
    printf("Run Time: real %.3f user %f sys %f\n",
       (ftWallEnd - ftWallBegin)*0.001,
       timeDiff(&ftUserBegin, &ftUserEnd),
       timeDiff(&ftKernelBegin, &ftKernelEnd));
  }
}

#define BEGIN_TIMER beginTimer()
#define END_TIMER endTimer()
#define HAS_TIMER hasTimer()

#else
#define BEGIN_TIMER 
#define END_TIMER
#define HAS_TIMER 0
#endif

/*
** Used to prevent warnings about unused parameters
*/
#define UNUSED_PARAMETER(x) (void)(x)

/*
** If the following flag is set, then command execution stops
** at an error if we are not interactive.
*/
static int bail_on_error = 0;

/*
** Threat stdin as an interactive input if the following variable
** is true.  Otherwise, assume stdin is connected to a file or pipe.
*/
static int stdin_is_interactive = 1;

/*
** The following is the open SQLite database.  We make a pointer
** to this database a static variable so that it can be accessed
** by the SIGINT handler to interrupt database processing.
*/
static sqlite3 *globalDb = 0;

/*
** True if an interrupt (Control-C) has been received.
*/
static volatile int seenInterrupt = 0;

/*
** This is the name of our program. It is set in main(), used
** in a number of other places, mostly for error messages.
*/
static char *Argv0;

/*
** Prompt strings. Initialized in main. Settable with
**   .prompt main continue
*/
static char mainPrompt[20];     /* First line prompt. default: "sqlite> "*/
static char continuePrompt[20]; /* Continuation prompt. default: "   ...> " */

/*
** Write I/O traces to the following stream.
*/
#ifdef SQLITE_ENABLE_IOTRACE
static FILE *iotrace = 0;
#endif

/*
** This routine works like printf in that its first argument is a
** format string and subsequent arguments are values to be substituted
** in place of % fields.  The result of formatting this string
** is written to iotrace.
*/
#ifdef SQLITE_ENABLE_IOTRACE
static void SQLITE_CDECL iotracePrintf(const char *zFormat, ...){
  va_list ap;
  char *z;
  if( iotrace==0 ) return;
  va_start(ap, zFormat);
  z = sqlite3_vmprintf(zFormat, ap);
  va_end(ap);
  fprintf(iotrace, "%s", z);
  sqlite3_free(z);
}
#endif


/*
** Determines if a string is a number of not.
*/
static int isNumber(const char *z, int *realnum){
  if( *z=='-' || *z=='+' ) z++;
  if( !IsDigit(*z) ){
    return 0;
  }
  z++;
  if( realnum ) *realnum = 0;
  while( IsDigit(*z) ){ z++; }
  if( *z=='.' ){
    z++;
    if( !IsDigit(*z) ) return 0;
    while( IsDigit(*z) ){ z++; }
    if( realnum ) *realnum = 1;
  }
  if( *z=='e' || *z=='E' ){
    z++;
    if( *z=='+' || *z=='-' ) z++;
    if( !IsDigit(*z) ) return 0;
    while( IsDigit(*z) ){ z++; }
    if( realnum ) *realnum = 1;
  }
  return *z==0;
}

/*
** A global char* and an SQL function to access its current value 
** from within an SQL statement. This program used to use the 
** sqlite_exec_printf() API to substitue a string into an SQL statement.
** The correct way to do this with sqlite3 is to use the bind API, but
** since the shell is built around the callback paradigm it would be a lot
** of work. Instead just use this hack, which is quite harmless.
*/
static const char *zShellStatic = 0;
static void shellstaticFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  assert( 0==argc );
  assert( zShellStatic );
  UNUSED_PARAMETER(argc);
  UNUSED_PARAMETER(argv);
  sqlite3_result_text(context, zShellStatic, -1, SQLITE_STATIC);
}


/*
** This routine reads a line of text from FILE in, stores
** the text in memory obtained from malloc() and returns a pointer
** to the text.  NULL is returned at end of file, or if malloc()
** fails.
**
** If zLine is not NULL then it is a malloced buffer returned from
** a previous call to this routine that may be reused.
*/
static char *local_getline(char *zLine, FILE *in){
  int nLine = zLine==0 ? 0 : 100;
  int n = 0;

  while( 1 ){
    if( n+100>nLine ){
      nLine = nLine*2 + 100;
      zLine = realloc(zLine, nLine);
      if( zLine==0 ) return 0;
    }
    if( fgets(&zLine[n], nLine - n, in)==0 ){
      if( n==0 ){
        free(zLine);
        return 0;
      }
      zLine[n] = 0;
      break;
    }
    while( zLine[n] ) n++;
    if( n>0 && zLine[n-1]=='\n' ){
      n--;
      if( n>0 && zLine[n-1]=='\r' ) n--;
      zLine[n] = 0;
      break;
    }
  }
  return zLine;
}

/*
** Retrieve a single line of input text.
**
** If in==0 then read from standard input and prompt before each line.
** If isContinuation is true, then a continuation prompt is appropriate.
** If isContinuation is zero, then the main prompt should be used.
**
** If zPrior is not NULL then it is a buffer from a prior call to this
** routine that can be reused.
**
** The result is stored in space obtained from malloc() and must either
** be freed by the caller or else passed back into this routine via the
** zPrior argument for reuse.
*/
static char *one_input_line(FILE *in, char *zPrior, int isContinuation){
  char *zPrompt;
  char *zResult;
  if( in!=0 ){
    zResult = local_getline(zPrior, in);
  }else{
    zPrompt = isContinuation ? continuePrompt : mainPrompt;
#if SHELL_USE_LOCAL_GETLINE
    printf("%s", zPrompt);
    fflush(stdout);
    zResult = local_getline(zPrior, stdin);
#else
    free(zPrior);
    zResult = shell_readline(zPrompt);
    if( zResult && *zResult ) shell_add_history(zResult);
#endif
  }
  return zResult;
}

/*
** Shell output mode information from before ".explain on", 
** saved so that it can be restored by ".explain off"
*/
typedef struct SavedModeInfo SavedModeInfo;
struct SavedModeInfo {
  int valid;          /* Is there legit data in here? */
  int mode;           /* Mode prior to ".explain on" */
  int showHeader;     /* The ".header" setting prior to ".explain on" */
  int colWidth[100];  /* Column widths prior to ".explain on" */
};

/*
** State information about the database connection is contained in an
** instance of the following structure.
*/
typedef struct ShellState ShellState;
struct ShellState {
  sqlite3 *db;           /* The database */
  int echoOn;            /* True to echo input commands */
  int autoEQP;           /* Run EXPLAIN QUERY PLAN prior to seach SQL stmt */
  int statsOn;           /* True to display memory stats before each finalize */
  int scanstatsOn;       /* True to display scan stats before each finalize */
  int backslashOn;       /* Resolve C-style \x escapes in SQL input text */
  int outCount;          /* Revert to stdout when reaching zero */
  int cnt;               /* Number of records displayed so far */
  FILE *out;             /* Write results here */
  FILE *traceOut;        /* Output for sqlite3_trace() */
  int nErr;              /* Number of errors seen */
  int mode;              /* An output mode setting */
  int writableSchema;    /* True if PRAGMA writable_schema=ON */
  int showHeader;        /* True to show column names in List or Column mode */
  unsigned shellFlgs;    /* Various flags */
  char *zDestTable;      /* Name of destination table when MODE_Insert */
  char colSeparator[20]; /* Column separator character for several modes */
  char rowSeparator[20]; /* Row separator character for MODE_Ascii */
  int colWidth[100];     /* Requested width of each column when in column mode*/
  int actualWidth[100];  /* Actual width of each column */
  char nullValue[20];    /* The text to print when a NULL comes back from
                         ** the database */
  SavedModeInfo normalMode;/* Holds the mode just before .explain ON */
  char outfile[FILENAME_MAX]; /* Filename for *out */
  const char *zDbFilename;    /* name of the database file */
  char *zFreeOnClose;         /* Filename to free when closing */
  const char *zVfs;           /* Name of VFS to use */
  sqlite3_stmt *pStmt;   /* Current statement if any. */
  FILE *pLog;            /* Write log output here */
  int *aiIndent;         /* Array of indents used in MODE_Explain */
  int nIndent;           /* Size of array aiIndent[] */
  int iIndent;           /* Index of current op in aiIndent[] */
};

/*
** These are the allowed shellFlgs values
*/
#define SHFLG_Scratch     0x00001     /* The --scratch option is used */
#define SHFLG_Pagecache   0x00002     /* The --pagecache option is used */
#define SHFLG_Lookaside   0x00004     /* Lookaside memory is used */

/*
** These are the allowed modes.
*/
#define MODE_Line     0  /* One column per line.  Blank line between records */
#define MODE_Column   1  /* One record per line in neat columns */
#define MODE_List     2  /* One record per line with a separator */
#define MODE_Semi     3  /* Same as MODE_List but append ";" to each line */
#define MODE_Html     4  /* Generate an XHTML table */
#define MODE_Insert   5  /* Generate SQL "insert" statements */
#define MODE_Tcl      6  /* Generate ANSI-C or TCL quoted elements */
#define MODE_Csv      7  /* Quote strings, numbers are plain */
#define MODE_Explain  8  /* Like MODE_Column, but do not truncate data */
#define MODE_Ascii    9  /* Use ASCII unit and record separators (0x1F/0x1E) */

static const char *modeDescr[] = {
  "line",
  "column",
  "list",
  "semi",
  "html",
  "insert",
  "tcl",
  "csv",
  "explain",
  "ascii",
};

/*
** These are the column/row/line separators used by the various
** import/export modes.
*/
#define SEP_Column    "|"
#define SEP_Row       "\n"
#define SEP_Tab       "\t"
#define SEP_Space     " "
#define SEP_Comma     ","
#define SEP_CrLf      "\r\n"
#define SEP_Unit      "\x1F"
#define SEP_Record    "\x1E"

/*
** Number of elements in an array
*/
#define ArraySize(X)  (int)(sizeof(X)/sizeof(X[0]))

/*
** Compute a string length that is limited to what can be stored in
** lower 30 bits of a 32-bit signed integer.
*/
static int strlen30(const char *z){
  const char *z2 = z;
  while( *z2 ){ z2++; }
  return 0x3fffffff & (int)(z2 - z);
}

/*
** A callback for the sqlite3_log() interface.
*/
static void shellLog(void *pArg, int iErrCode, const char *zMsg){
  ShellState *p = (ShellState*)pArg;
  if( p->pLog==0 ) return;
  fprintf(p->pLog, "(%d) %s\n", iErrCode, zMsg);
  fflush(p->pLog);
}

/*
** Output the given string as a hex-encoded blob (eg. X'1234' )
*/
static void output_hex_blob(FILE *out, const void *pBlob, int nBlob){
  int i;
  char *zBlob = (char *)pBlob;
  fprintf(out,"X'");
  for(i=0; i<nBlob; i++){ fprintf(out,"%02x",zBlob[i]&0xff); }
  fprintf(out,"'");
}

/*
** Output the given string as a quoted string using SQL quoting conventions.
*/
static void output_quoted_string(FILE *out, const char *z){
  int i;
  int nSingle = 0;
  setBinaryMode(out);
  for(i=0; z[i]; i++){
    if( z[i]=='\'' ) nSingle++;
  }
  if( nSingle==0 ){
    fprintf(out,"'%s'",z);
  }else{
    fprintf(out,"'");
    while( *z ){
      for(i=0; z[i] && z[i]!='\''; i++){}
      if( i==0 ){
        fprintf(out,"''");
        z++;
      }else if( z[i]=='\'' ){
        fprintf(out,"%.*s''",i,z);
        z += i+1;
      }else{
        fprintf(out,"%s",z);
        break;
      }
    }
    fprintf(out,"'");
  }
  setTextMode(out);
}

/*
** Output the given string as a quoted according to C or TCL quoting rules.
*/
static void output_c_string(FILE *out, const char *z){
  unsigned int c;
  fputc('"', out);
  while( (c = *(z++))!=0 ){
    if( c=='\\' ){
      fputc(c, out);
      fputc(c, out);
    }else if( c=='"' ){
      fputc('\\', out);
      fputc('"', out);
    }else if( c=='\t' ){
      fputc('\\', out);
      fputc('t', out);
    }else if( c=='\n' ){
      fputc('\\', out);
      fputc('n', out);
    }else if( c=='\r' ){
      fputc('\\', out);
      fputc('r', out);
    }else if( !isprint(c&0xff) ){
      fprintf(out, "\\%03o", c&0xff);
    }else{
      fputc(c, out);
    }
  }
  fputc('"', out);
}

/*
** Output the given string with characters that are special to
** HTML escaped.
*/
static void output_html_string(FILE *out, const char *z){
  int i;
  if( z==0 ) z = "";
  while( *z ){
    for(i=0;   z[i] 
            && z[i]!='<' 
            && z[i]!='&' 
            && z[i]!='>' 
            && z[i]!='\"' 
            && z[i]!='\'';
        i++){}
    if( i>0 ){
      fprintf(out,"%.*s",i,z);
    }
    if( z[i]=='<' ){
      fprintf(out,"&lt;");
    }else if( z[i]=='&' ){
      fprintf(out,"&amp;");
    }else if( z[i]=='>' ){
      fprintf(out,"&gt;");
    }else if( z[i]=='\"' ){
      fprintf(out,"&quot;");
    }else if( z[i]=='\'' ){
      fprintf(out,"&#39;");
    }else{
      break;
    }
    z += i + 1;
  }
}

/*
** If a field contains any character identified by a 1 in the following
** array, then the string must be quoted for CSV.
*/
static const char needCsvQuote[] = {
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 0, 1, 0, 0, 0, 0, 1,   0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 1, 
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,   
};

/*
** Output a single term of CSV.  Actually, p->colSeparator is used for
** the separator, which may or may not be a comma.  p->nullValue is
** the null value.  Strings are quoted if necessary.  The separator
** is only issued if bSep is true.
*/
static void output_csv(ShellState *p, const char *z, int bSep){
  FILE *out = p->out;
  if( z==0 ){
    fprintf(out,"%s",p->nullValue);
  }else{
    int i;
    int nSep = strlen30(p->colSeparator);
    for(i=0; z[i]; i++){
      if( needCsvQuote[((unsigned char*)z)[i]] 
         || (z[i]==p->colSeparator[0] && 
             (nSep==1 || memcmp(z, p->colSeparator, nSep)==0)) ){
        i = 0;
        break;
      }
    }
    if( i==0 ){
      putc('"', out);
      for(i=0; z[i]; i++){
        if( z[i]=='"' ) putc('"', out);
        putc(z[i], out);
      }
      putc('"', out);
    }else{
      fprintf(out, "%s", z);
    }
  }
  if( bSep ){
    fprintf(p->out, "%s", p->colSeparator);
  }
}

#ifdef SIGINT
/*
** This routine runs when the user presses Ctrl-C
*/
static void interrupt_handler(int NotUsed){
  UNUSED_PARAMETER(NotUsed);
  seenInterrupt++;
  if( seenInterrupt>2 ) exit(1);
  if( globalDb ) sqlite3_interrupt(globalDb);
}
#endif

/*
** This is the callback routine that the shell
** invokes for each row of a query result.
*/
static int shell_callback(
  void *pArg,
  int nArg,        /* Number of result columns */
  char **azArg,    /* Text of each result column */
  char **azCol,    /* Column names */
  int *aiType      /* Column types */
){
  int i;
  ShellState *p = (ShellState*)pArg;

  switch( p->mode ){
    case MODE_Line: {
      int w = 5;
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        int len = strlen30(azCol[i] ? azCol[i] : "");
        if( len>w ) w = len;
      }
      if( p->cnt++>0 ) fprintf(p->out, "%s", p->rowSeparator);
      for(i=0; i<nArg; i++){
        fprintf(p->out,"%*s = %s%s", w, azCol[i],
                azArg[i] ? azArg[i] : p->nullValue, p->rowSeparator);
      }
      break;
    }
    case MODE_Explain:
    case MODE_Column: {
      if( p->cnt++==0 ){
        for(i=0; i<nArg; i++){
          int w, n;
          if( i<ArraySize(p->colWidth) ){
            w = p->colWidth[i];
          }else{
            w = 0;
          }
          if( w==0 ){
            w = strlen30(azCol[i] ? azCol[i] : "");
            if( w<10 ) w = 10;
            n = strlen30(azArg && azArg[i] ? azArg[i] : p->nullValue);
            if( w<n ) w = n;
          }
          if( i<ArraySize(p->actualWidth) ){
            p->actualWidth[i] = w;
          }
          if( p->showHeader ){
            if( w<0 ){
              fprintf(p->out,"%*.*s%s",-w,-w,azCol[i],
                      i==nArg-1 ? p->rowSeparator : "  ");
            }else{
              fprintf(p->out,"%-*.*s%s",w,w,azCol[i],
                      i==nArg-1 ? p->rowSeparator : "  ");
            }
          }
        }
        if( p->showHeader ){
          for(i=0; i<nArg; i++){
            int w;
            if( i<ArraySize(p->actualWidth) ){
               w = p->actualWidth[i];
               if( w<0 ) w = -w;
            }else{
               w = 10;
            }
            fprintf(p->out,"%-*.*s%s",w,w,"-----------------------------------"
                   "----------------------------------------------------------",
                    i==nArg-1 ? p->rowSeparator : "  ");
          }
        }
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        int w;
        if( i<ArraySize(p->actualWidth) ){
           w = p->actualWidth[i];
        }else{
           w = 10;
        }
        if( p->mode==MODE_Explain && azArg[i] && strlen30(azArg[i])>w ){
          w = strlen30(azArg[i]);
        }
        if( i==1 && p->aiIndent && p->pStmt ){
          if( p->iIndent<p->nIndent ){
            fprintf(p->out, "%*.s", p->aiIndent[p->iIndent], "");
          }
          p->iIndent++;
        }
        if( w<0 ){
          fprintf(p->out,"%*.*s%s",-w,-w,
              azArg[i] ? azArg[i] : p->nullValue,
              i==nArg-1 ? p->rowSeparator : "  ");
        }else{
          fprintf(p->out,"%-*.*s%s",w,w,
              azArg[i] ? azArg[i] : p->nullValue,
              i==nArg-1 ? p->rowSeparator : "  ");
        }
      }
      break;
    }
    case MODE_Semi:
    case MODE_List: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          fprintf(p->out,"%s%s",azCol[i],
                  i==nArg-1 ? p->rowSeparator : p->colSeparator);
        }
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        char *z = azArg[i];
        if( z==0 ) z = p->nullValue;
        fprintf(p->out, "%s", z);
        if( i<nArg-1 ){
          fprintf(p->out, "%s", p->colSeparator);
        }else if( p->mode==MODE_Semi ){
          fprintf(p->out, ";%s", p->rowSeparator);
        }else{
          fprintf(p->out, "%s", p->rowSeparator);
        }
      }
      break;
    }
    case MODE_Html: {
      if( p->cnt++==0 && p->showHeader ){
        fprintf(p->out,"<TR>");
        for(i=0; i<nArg; i++){
          fprintf(p->out,"<TH>");
          output_html_string(p->out, azCol[i]);
          fprintf(p->out,"</TH>\n");
        }
        fprintf(p->out,"</TR>\n");
      }
      if( azArg==0 ) break;
      fprintf(p->out,"<TR>");
      for(i=0; i<nArg; i++){
        fprintf(p->out,"<TD>");
        output_html_string(p->out, azArg[i] ? azArg[i] : p->nullValue);
        fprintf(p->out,"</TD>\n");
      }
      fprintf(p->out,"</TR>\n");
      break;
    }
    case MODE_Tcl: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          output_c_string(p->out,azCol[i] ? azCol[i] : "");
          if(i<nArg-1) fprintf(p->out, "%s", p->colSeparator);
        }
        fprintf(p->out, "%s", p->rowSeparator);
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        output_c_string(p->out, azArg[i] ? azArg[i] : p->nullValue);
        if(i<nArg-1) fprintf(p->out, "%s", p->colSeparator);
      }
      fprintf(p->out, "%s", p->rowSeparator);
      break;
    }
    case MODE_Csv: {
      setBinaryMode(p->out);
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          output_csv(p, azCol[i] ? azCol[i] : "", i<nArg-1);
        }
        fprintf(p->out, "%s", p->rowSeparator);
      }
      if( nArg>0 ){
        for(i=0; i<nArg; i++){
          output_csv(p, azArg[i], i<nArg-1);
        }
        fprintf(p->out, "%s", p->rowSeparator);
      }
      setTextMode(p->out);
      break;
    }
    case MODE_Insert: {
      p->cnt++;
      if( azArg==0 ) break;
      fprintf(p->out,"INSERT INTO %s",p->zDestTable);
      if( p->showHeader ){
        fprintf(p->out,"(");
        for(i=0; i<nArg; i++){
          char *zSep = i>0 ? ",": "";
          fprintf(p->out, "%s%s", zSep, azCol[i]);
        }
        fprintf(p->out,")");
      }
      fprintf(p->out," VALUES(");
      for(i=0; i<nArg; i++){
        char *zSep = i>0 ? ",": "";
        if( (azArg[i]==0) || (aiType && aiType[i]==SQLITE_NULL) ){
          fprintf(p->out,"%sNULL",zSep);
        }else if( aiType && aiType[i]==SQLITE_TEXT ){
          if( zSep[0] ) fprintf(p->out,"%s",zSep);
          output_quoted_string(p->out, azArg[i]);
        }else if( aiType && (aiType[i]==SQLITE_INTEGER
                             || aiType[i]==SQLITE_FLOAT) ){
          fprintf(p->out,"%s%s",zSep, azArg[i]);
        }else if( aiType && aiType[i]==SQLITE_BLOB && p->pStmt ){
          const void *pBlob = sqlite3_column_blob(p->pStmt, i);
          int nBlob = sqlite3_column_bytes(p->pStmt, i);
          if( zSep[0] ) fprintf(p->out,"%s",zSep);
          output_hex_blob(p->out, pBlob, nBlob);
        }else if( isNumber(azArg[i], 0) ){
          fprintf(p->out,"%s%s",zSep, azArg[i]);
        }else{
          if( zSep[0] ) fprintf(p->out,"%s",zSep);
          output_quoted_string(p->out, azArg[i]);
        }
      }
      fprintf(p->out,");\n");
      break;
    }
    case MODE_Ascii: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          if( i>0 ) fprintf(p->out, "%s", p->colSeparator);
          fprintf(p->out,"%s",azCol[i] ? azCol[i] : "");
        }
        fprintf(p->out, "%s", p->rowSeparator);
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        if( i>0 ) fprintf(p->out, "%s", p->colSeparator);
        fprintf(p->out,"%s",azArg[i] ? azArg[i] : p->nullValue);
      }
      fprintf(p->out, "%s", p->rowSeparator);
      break;
    }
  }
  return 0;
}

/*
** This is the callback routine that the SQLite library
** invokes for each row of a query result.
*/
static int callback(void *pArg, int nArg, char **azArg, char **azCol){
  /* since we don't have type info, call the shell_callback with a NULL value */
  return shell_callback(pArg, nArg, azArg, azCol, NULL);
}

/*
** Set the destination table field of the ShellState structure to
** the name of the table given.  Escape any quote characters in the
** table name.
*/
static void set_table_name(ShellState *p, const char *zName){
  int i, n;
  int needQuote;
  char *z;

  if( p->zDestTable ){
    free(p->zDestTable);
    p->zDestTable = 0;
  }
  if( zName==0 ) return;
  needQuote = !isalpha((unsigned char)*zName) && *zName!='_';
  for(i=n=0; zName[i]; i++, n++){
    if( !isalnum((unsigned char)zName[i]) && zName[i]!='_' ){
      needQuote = 1;
      if( zName[i]=='\'' ) n++;
    }
  }
  if( needQuote ) n += 2;
  z = p->zDestTable = malloc( n+1 );
  if( z==0 ){
    fprintf(stderr,"Error: out of memory\n");
    exit(1);
  }
  n = 0;
  if( needQuote ) z[n++] = '\'';
  for(i=0; zName[i]; i++){
    z[n++] = zName[i];
    if( zName[i]=='\'' ) z[n++] = '\'';
  }
  if( needQuote ) z[n++] = '\'';
  z[n] = 0;
}

/* zIn is either a pointer to a NULL-terminated string in memory obtained
** from malloc(), or a NULL pointer. The string pointed to by zAppend is
** added to zIn, and the result returned in memory obtained from malloc().
** zIn, if it was not NULL, is freed.
**
** If the third argument, quote, is not '\0', then it is used as a 
** quote character for zAppend.
*/
static char *appendText(char *zIn, char const *zAppend, char quote){
  int len;
  int i;
  int nAppend = strlen30(zAppend);
  int nIn = (zIn?strlen30(zIn):0);

  len = nAppend+nIn+1;
  if( quote ){
    len += 2;
    for(i=0; i<nAppend; i++){
      if( zAppend[i]==quote ) len++;
    }
  }

  zIn = (char *)realloc(zIn, len);
  if( !zIn ){
    return 0;
  }

  if( quote ){
    char *zCsr = &zIn[nIn];
    *zCsr++ = quote;
    for(i=0; i<nAppend; i++){
      *zCsr++ = zAppend[i];
      if( zAppend[i]==quote ) *zCsr++ = quote;
    }
    *zCsr++ = quote;
    *zCsr++ = '\0';
    assert( (zCsr-zIn)==len );
  }else{
    memcpy(&zIn[nIn], zAppend, nAppend);
    zIn[len-1] = '\0';
  }

  return zIn;
}


/*
** Execute a query statement that will generate SQL output.  Print
** the result columns, comma-separated, on a line and then add a
** semicolon terminator to the end of that line.
**
** If the number of columns is 1 and that column contains text "--"
** then write the semicolon on a separate line.  That way, if a 
** "--" comment occurs at the end of the statement, the comment
** won't consume the semicolon terminator.
*/
static int run_table_dump_query(
  ShellState *p,           /* Query context */
  const char *zSelect,     /* SELECT statement to extract content */
  const char *zFirstRow    /* Print before first row, if not NULL */
){
  sqlite3_stmt *pSelect;
  int rc;
  int nResult;
  int i;
  const char *z;
  rc = sqlite3_prepare_v2(p->db, zSelect, -1, &pSelect, 0);
  if( rc!=SQLITE_OK || !pSelect ){
    fprintf(p->out, "/**** ERROR: (%d) %s *****/\n", rc, sqlite3_errmsg(p->db));
    if( (rc&0xff)!=SQLITE_CORRUPT ) p->nErr++;
    return rc;
  }
  rc = sqlite3_step(pSelect);
  nResult = sqlite3_column_count(pSelect);
  while( rc==SQLITE_ROW ){
    if( zFirstRow ){
      fprintf(p->out, "%s", zFirstRow);
      zFirstRow = 0;
    }
    z = (const char*)sqlite3_column_text(pSelect, 0);
    fprintf(p->out, "%s", z);
    for(i=1; i<nResult; i++){ 
      fprintf(p->out, ",%s", sqlite3_column_text(pSelect, i));
    }
    if( z==0 ) z = "";
    while( z[0] && (z[0]!='-' || z[1]!='-') ) z++;
    if( z[0] ){
      fprintf(p->out, "\n;\n");
    }else{
      fprintf(p->out, ";\n");
    }    
    rc = sqlite3_step(pSelect);
  }
  rc = sqlite3_finalize(pSelect);
  if( rc!=SQLITE_OK ){
    fprintf(p->out, "/**** ERROR: (%d) %s *****/\n", rc, sqlite3_errmsg(p->db));
    if( (rc&0xff)!=SQLITE_CORRUPT ) p->nErr++;
  }
  return rc;
}

/*
** Allocate space and save off current error string.
*/
static char *save_err_msg(
  sqlite3 *db            /* Database to query */
){
  int nErrMsg = 1+strlen30(sqlite3_errmsg(db));
  char *zErrMsg = sqlite3_malloc64(nErrMsg);
  if( zErrMsg ){
    memcpy(zErrMsg, sqlite3_errmsg(db), nErrMsg);
  }
  return zErrMsg;
}

/*
** Display memory stats.
*/
static int display_stats(
  sqlite3 *db,                /* Database to query */
  ShellState *pArg,           /* Pointer to ShellState */
  int bReset                  /* True to reset the stats */
){
  int iCur;
  int iHiwtr;

  if( pArg && pArg->out ){
    
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MEMORY_USED, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out,
            "Memory Used:                         %d (max %d) bytes\n",
            iCur, iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MALLOC_COUNT, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Number of Outstanding Allocations:   %d (max %d)\n",
            iCur, iHiwtr);
    if( pArg->shellFlgs & SHFLG_Pagecache ){
      iHiwtr = iCur = -1;
      sqlite3_status(SQLITE_STATUS_PAGECACHE_USED, &iCur, &iHiwtr, bReset);
      fprintf(pArg->out,
              "Number of Pcache Pages Used:         %d (max %d) pages\n",
              iCur, iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PAGECACHE_OVERFLOW, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out,
            "Number of Pcache Overflow Bytes:     %d (max %d) bytes\n",
            iCur, iHiwtr);
    if( pArg->shellFlgs & SHFLG_Scratch ){
      iHiwtr = iCur = -1;
      sqlite3_status(SQLITE_STATUS_SCRATCH_USED, &iCur, &iHiwtr, bReset);
      fprintf(pArg->out, "Number of Scratch Allocations Used:  %d (max %d)\n",
              iCur, iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_SCRATCH_OVERFLOW, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out,
            "Number of Scratch Overflow Bytes:    %d (max %d) bytes\n",
            iCur, iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MALLOC_SIZE, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Largest Allocation:                  %d bytes\n",
            iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PAGECACHE_SIZE, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Largest Pcache Allocation:           %d bytes\n",
            iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_SCRATCH_SIZE, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Largest Scratch Allocation:          %d bytes\n",
            iHiwtr);
#ifdef YYTRACKMAXSTACKDEPTH
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PARSER_STACK, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Deepest Parser Stack:                %d (max %d)\n",
            iCur, iHiwtr);
#endif
  }

  if( pArg && pArg->out && db ){
    if( pArg->shellFlgs & SHFLG_Lookaside ){
      iHiwtr = iCur = -1;
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_USED,
                        &iCur, &iHiwtr, bReset);
      fprintf(pArg->out, "Lookaside Slots Used:                %d (max %d)\n",
              iCur, iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_HIT,
                        &iCur, &iHiwtr, bReset);
      fprintf(pArg->out, "Successful lookaside attempts:       %d\n", iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_MISS_SIZE,
                        &iCur, &iHiwtr, bReset);
      fprintf(pArg->out, "Lookaside failures due to size:      %d\n", iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_MISS_FULL,
                        &iCur, &iHiwtr, bReset);
      fprintf(pArg->out, "Lookaside failures due to OOM:       %d\n", iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_USED, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Pager Heap Usage:                    %d bytes\n",iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_HIT, &iCur, &iHiwtr, 1);
    fprintf(pArg->out, "Page cache hits:                     %d\n", iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_MISS, &iCur, &iHiwtr, 1);
    fprintf(pArg->out, "Page cache misses:                   %d\n", iCur); 
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_WRITE, &iCur, &iHiwtr, 1);
    fprintf(pArg->out, "Page cache writes:                   %d\n", iCur); 
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_SCHEMA_USED, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Schema Heap Usage:                   %d bytes\n",iCur); 
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_STMT_USED, &iCur, &iHiwtr, bReset);
    fprintf(pArg->out, "Statement Heap/Lookaside Usage:      %d bytes\n",iCur); 
  }

  if( pArg && pArg->out && db && pArg->pStmt ){
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_FULLSCAN_STEP,
                               bReset);
    fprintf(pArg->out, "Fullscan Steps:                      %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_SORT, bReset);
    fprintf(pArg->out, "Sort Operations:                     %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_AUTOINDEX,bReset);
    fprintf(pArg->out, "Autoindex Inserts:                   %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_VM_STEP, bReset);
    fprintf(pArg->out, "Virtual Machine Steps:               %d\n", iCur);
  }

  return 0;
}

/*
** Display scan stats.
*/
static void display_scanstats(
  sqlite3 *db,                    /* Database to query */
  ShellState *pArg                /* Pointer to ShellState */
){
#ifndef SQLITE_ENABLE_STMT_SCANSTATUS
  UNUSED_PARAMETER(db);
  UNUSED_PARAMETER(pArg);
#else
  int i, k, n, mx;
  fprintf(pArg->out, "-------- scanstats --------\n");
  mx = 0;
  for(k=0; k<=mx; k++){
    double rEstLoop = 1.0;
    for(i=n=0; 1; i++){
      sqlite3_stmt *p = pArg->pStmt;
      sqlite3_int64 nLoop, nVisit;
      double rEst;
      int iSid;
      const char *zExplain;
      if( sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_NLOOP, (void*)&nLoop) ){
        break;
      }
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_SELECTID, (void*)&iSid);
      if( iSid>mx ) mx = iSid;
      if( iSid!=k ) continue;
      if( n==0 ){
        rEstLoop = (double)nLoop;
        if( k>0 ) fprintf(pArg->out, "-------- subquery %d -------\n", k);
      }
      n++;
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_NVISIT, (void*)&nVisit);
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_EST, (void*)&rEst);
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_EXPLAIN, (void*)&zExplain);
      fprintf(pArg->out, "Loop %2d: %s\n", n, zExplain);
      rEstLoop *= rEst;
      fprintf(pArg->out, 
          "         nLoop=%-8lld nRow=%-8lld estRow=%-8lld estRow/Loop=%-8g\n",
          nLoop, nVisit, (sqlite3_int64)(rEstLoop+0.5), rEst
      );
    }
  }
  fprintf(pArg->out, "---------------------------\n");
#endif
}

/*
** Parameter azArray points to a zero-terminated array of strings. zStr
** points to a single nul-terminated string. Return non-zero if zStr
** is equal, according to strcmp(), to any of the strings in the array.
** Otherwise, return zero.
*/
static int str_in_array(const char *zStr, const char **azArray){
  int i;
  for(i=0; azArray[i]; i++){
    if( 0==strcmp(zStr, azArray[i]) ) return 1;
  }
  return 0;
}

/*
** If compiled statement pSql appears to be an EXPLAIN statement, allocate
** and populate the ShellState.aiIndent[] array with the number of
** spaces each opcode should be indented before it is output. 
**
** The indenting rules are:
**
**     * For each "Next", "Prev", "VNext" or "VPrev" instruction, indent
**       all opcodes that occur between the p2 jump destination and the opcode
**       itself by 2 spaces.
**
**     * For each "Goto", if the jump destination is earlier in the program
**       and ends on one of:
**          Yield  SeekGt  SeekLt  RowSetRead  Rewind
**       or if the P1 parameter is one instead of zero,
**       then indent all opcodes between the earlier instruction
**       and "Goto" by 2 spaces.
*/
static void explain_data_prepare(ShellState *p, sqlite3_stmt *pSql){
  const char *zSql;               /* The text of the SQL statement */
  const char *z;                  /* Used to check if this is an EXPLAIN */
  int *abYield = 0;               /* True if op is an OP_Yield */
  int nAlloc = 0;                 /* Allocated size of p->aiIndent[], abYield */
  int iOp;                        /* Index of operation in p->aiIndent[] */

  const char *azNext[] = { "Next", "Prev", "VPrev", "VNext", "SorterNext",
                           "NextIfOpen", "PrevIfOpen", 0 };
  const char *azYield[] = { "Yield", "SeekLT", "SeekGT", "RowSetRead",
                            "Rewind", 0 };
  const char *azGoto[] = { "Goto", 0 };

  /* Try to figure out if this is really an EXPLAIN statement. If this
  ** cannot be verified, return early.  */
  zSql = sqlite3_sql(pSql);
  if( zSql==0 ) return;
  for(z=zSql; *z==' ' || *z=='\t' || *z=='\n' || *z=='\f' || *z=='\r'; z++);
  if( sqlite3_strnicmp(z, "explain", 7) ) return;

  for(iOp=0; SQLITE_ROW==sqlite3_step(pSql); iOp++){
    int i;
    int iAddr = sqlite3_column_int(pSql, 0);
    const char *zOp = (const char*)sqlite3_column_text(pSql, 1);

    /* Set p2 to the P2 field of the current opcode. Then, assuming that
    ** p2 is an instruction address, set variable p2op to the index of that
    ** instruction in the aiIndent[] array. p2 and p2op may be different if
    ** the current instruction is part of a sub-program generated by an
    ** SQL trigger or foreign key.  */
    int p2 = sqlite3_column_int(pSql, 3);
    int p2op = (p2 + (iOp-iAddr));

    /* Grow the p->aiIndent array as required */
    if( iOp>=nAlloc ){
      nAlloc += 100;
      p->aiIndent = (int*)sqlite3_realloc64(p->aiIndent, nAlloc*sizeof(int));
      abYield = (int*)sqlite3_realloc64(abYield, nAlloc*sizeof(int));
    }
    abYield[iOp] = str_in_array(zOp, azYield);
    p->aiIndent[iOp] = 0;
    p->nIndent = iOp+1;

    if( str_in_array(zOp, azNext) ){
      for(i=p2op; i<iOp; i++) p->aiIndent[i] += 2;
    }
    if( str_in_array(zOp, azGoto) && p2op<p->nIndent
     && (abYield[p2op] || sqlite3_column_int(pSql, 2))
    ){
      for(i=p2op+1; i<iOp; i++) p->aiIndent[i] += 2;
    }
  }

  p->iIndent = 0;
  sqlite3_free(abYield);
  sqlite3_reset(pSql);
}

/*
** Free the array allocated by explain_data_prepare().
*/
static void explain_data_delete(ShellState *p){
  sqlite3_free(p->aiIndent);
  p->aiIndent = 0;
  p->nIndent = 0;
  p->iIndent = 0;
}

/*
** Execute a statement or set of statements.  Print 
** any result rows/columns depending on the current mode 
** set via the supplied callback.
**
** This is very similar to SQLite's built-in sqlite3_exec() 
** function except it takes a slightly different callback 
** and callback data argument.
*/
static int shell_exec(
  sqlite3 *db,                              /* An open database */
  const char *zSql,                         /* SQL to be evaluated */
  int (*xCallback)(void*,int,char**,char**,int*),   /* Callback function */
                                            /* (not the same as sqlite3_exec) */
  ShellState *pArg,                         /* Pointer to ShellState */
  char **pzErrMsg                           /* Error msg written here */
){
  sqlite3_stmt *pStmt = NULL;     /* Statement to execute. */
  int rc = SQLITE_OK;             /* Return Code */
  int rc2;
  const char *zLeftover;          /* Tail of unprocessed SQL */

  if( pzErrMsg ){
    *pzErrMsg = NULL;
  }

  while( zSql[0] && (SQLITE_OK == rc) ){
    rc = sqlite3_prepare_v2(db, zSql, -1, &pStmt, &zLeftover);
    if( SQLITE_OK != rc ){
      if( pzErrMsg ){
        *pzErrMsg = save_err_msg(db);
      }
    }else{
      if( !pStmt ){
        /* this happens for a comment or white-space */
        zSql = zLeftover;
        while( IsSpace(zSql[0]) ) zSql++;
        continue;
      }

      /* save off the prepared statment handle and reset row count */
      if( pArg ){
        pArg->pStmt = pStmt;
        pArg->cnt = 0;
      }

      /* echo the sql statement if echo on */
      if( pArg && pArg->echoOn ){
        const char *zStmtSql = sqlite3_sql(pStmt);
        fprintf(pArg->out, "%s\n", zStmtSql ? zStmtSql : zSql);
      }

      /* Show the EXPLAIN QUERY PLAN if .eqp is on */
      if( pArg && pArg->autoEQP ){
        sqlite3_stmt *pExplain;
        char *zEQP = sqlite3_mprintf("EXPLAIN QUERY PLAN %s",
                                     sqlite3_sql(pStmt));
        rc = sqlite3_prepare_v2(db, zEQP, -1, &pExplain, 0);
        if( rc==SQLITE_OK ){
          while( sqlite3_step(pExplain)==SQLITE_ROW ){
            fprintf(pArg->out,"--EQP-- %d,", sqlite3_column_int(pExplain, 0));
            fprintf(pArg->out,"%d,", sqlite3_column_int(pExplain, 1));
            fprintf(pArg->out,"%d,", sqlite3_column_int(pExplain, 2));
            fprintf(pArg->out,"%s\n", sqlite3_column_text(pExplain, 3));
          }
        }
        sqlite3_finalize(pExplain);
        sqlite3_free(zEQP);
      }

      /* If the shell is currently in ".explain" mode, gather the extra
      ** data required to add indents to the output.*/
      if( pArg && pArg->mode==MODE_Explain ){
        explain_data_prepare(pArg, pStmt);
      }

      /* perform the first step.  this will tell us if we
      ** have a result set or not and how wide it is.
      */
      rc = sqlite3_step(pStmt);
      /* if we have a result set... */
      if( SQLITE_ROW == rc ){
        /* if we have a callback... */
        if( xCallback ){
          /* allocate space for col name ptr, value ptr, and type */
          int nCol = sqlite3_column_count(pStmt);
          void *pData = sqlite3_malloc64(3*nCol*sizeof(const char*) + 1);
          if( !pData ){
            rc = SQLITE_NOMEM;
          }else{
            char **azCols = (char **)pData;      /* Names of result columns */
            char **azVals = &azCols[nCol];       /* Results */
            int *aiTypes = (int *)&azVals[nCol]; /* Result types */
            int i, x;
            assert(sizeof(int) <= sizeof(char *)); 
            /* save off ptrs to column names */
            for(i=0; i<nCol; i++){
              azCols[i] = (char *)sqlite3_column_name(pStmt, i);
            }
            do{
              /* extract the data and data types */
              for(i=0; i<nCol; i++){
                aiTypes[i] = x = sqlite3_column_type(pStmt, i);
                if( x==SQLITE_BLOB && pArg && pArg->mode==MODE_Insert ){
                  azVals[i] = "";
                }else{
                  azVals[i] = (char*)sqlite3_column_text(pStmt, i);
                }
                if( !azVals[i] && (aiTypes[i]!=SQLITE_NULL) ){
                  rc = SQLITE_NOMEM;
                  break; /* from for */
                }
              } /* end for */

              /* if data and types extracted successfully... */
              if( SQLITE_ROW == rc ){ 
                /* call the supplied callback with the result row data */
                if( xCallback(pArg, nCol, azVals, azCols, aiTypes) ){
                  rc = SQLITE_ABORT;
                }else{
                  rc = sqlite3_step(pStmt);
                }
              }
            } while( SQLITE_ROW == rc );
            sqlite3_free(pData);
          }
        }else{
          do{
            rc = sqlite3_step(pStmt);
          } while( rc == SQLITE_ROW );
        }
      }

      explain_data_delete(pArg);

      /* print usage stats if stats on */
      if( pArg && pArg->statsOn ){
        display_stats(db, pArg, 0);
      }

      /* print loop-counters if required */
      if( pArg && pArg->scanstatsOn ){
        display_scanstats(db, pArg);
      }

      /* Finalize the statement just executed. If this fails, save a 
      ** copy of the error message. Otherwise, set zSql to point to the
      ** next statement to execute. */
      rc2 = sqlite3_finalize(pStmt);
      if( rc!=SQLITE_NOMEM ) rc = rc2;
      if( rc==SQLITE_OK ){
        zSql = zLeftover;
        while( IsSpace(zSql[0]) ) zSql++;
      }else if( pzErrMsg ){
        *pzErrMsg = save_err_msg(db);
      }

      /* clear saved stmt handle */
      if( pArg ){
        pArg->pStmt = NULL;
      }
    }
  } /* end while */

  return rc;
}


/*
** This is a different callback routine used for dumping the database.
** Each row received by this callback consists of a table name,
** the table type ("index" or "table") and SQL to create the table.
** This routine should print text sufficient to recreate the table.
*/
static int dump_callback(void *pArg, int nArg, char **azArg, char **azCol){
  int rc;
  const char *zTable;
  const char *zType;
  const char *zSql;
  const char *zPrepStmt = 0;
  ShellState *p = (ShellState *)pArg;

  UNUSED_PARAMETER(azCol);
  if( nArg!=3 ) return 1;
  zTable = azArg[0];
  zType = azArg[1];
  zSql = azArg[2];
  
  if( strcmp(zTable, "sqlite_sequence")==0 ){
    zPrepStmt = "DELETE FROM sqlite_sequence;\n";
  }else if( sqlite3_strglob("sqlite_stat?", zTable)==0 ){
    fprintf(p->out, "ANALYZE sqlite_master;\n");
  }else if( strncmp(zTable, "sqlite_", 7)==0 ){
    return 0;
  }else if( strncmp(zSql, "CREATE VIRTUAL TABLE", 20)==0 ){
    char *zIns;
    if( !p->writableSchema ){
      fprintf(p->out, "PRAGMA writable_schema=ON;\n");
      p->writableSchema = 1;
    }
    zIns = sqlite3_mprintf(
       "INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)"
       "VALUES('table','%q','%q',0,'%q');",
       zTable, zTable, zSql);
    fprintf(p->out, "%s\n", zIns);
    sqlite3_free(zIns);
    return 0;
  }else{
    fprintf(p->out, "%s;\n", zSql);
  }

  if( strcmp(zType, "table")==0 ){
    sqlite3_stmt *pTableInfo = 0;
    char *zSelect = 0;
    char *zTableInfo = 0;
    char *zTmp = 0;
    int nRow = 0;
   
    zTableInfo = appendText(zTableInfo, "PRAGMA table_info(", 0);
    zTableInfo = appendText(zTableInfo, zTable, '"');
    zTableInfo = appendText(zTableInfo, ");", 0);

    rc = sqlite3_prepare_v2(p->db, zTableInfo, -1, &pTableInfo, 0);
    free(zTableInfo);
    if( rc!=SQLITE_OK || !pTableInfo ){
      return 1;
    }

    zSelect = appendText(zSelect, "SELECT 'INSERT INTO ' || ", 0);
    /* Always quote the table name, even if it appears to be pure ascii,
    ** in case it is a keyword. Ex:  INSERT INTO "table" ... */
    zTmp = appendText(zTmp, zTable, '"');
    if( zTmp ){
      zSelect = appendText(zSelect, zTmp, '\'');
      free(zTmp);
    }
    zSelect = appendText(zSelect, " || ' VALUES(' || ", 0);
    rc = sqlite3_step(pTableInfo);
    while( rc==SQLITE_ROW ){
      const char *zText = (const char *)sqlite3_column_text(pTableInfo, 1);
      zSelect = appendText(zSelect, "quote(", 0);
      zSelect = appendText(zSelect, zText, '"');
      rc = sqlite3_step(pTableInfo);
      if( rc==SQLITE_ROW ){
        zSelect = appendText(zSelect, "), ", 0);
      }else{
        zSelect = appendText(zSelect, ") ", 0);
      }
      nRow++;
    }
    rc = sqlite3_finalize(pTableInfo);
    if( rc!=SQLITE_OK || nRow==0 ){
      free(zSelect);
      return 1;
    }
    zSelect = appendText(zSelect, "|| ')' FROM  ", 0);
    zSelect = appendText(zSelect, zTable, '"');

    rc = run_table_dump_query(p, zSelect, zPrepStmt);
    if( rc==SQLITE_CORRUPT ){
      zSelect = appendText(zSelect, " ORDER BY rowid DESC", 0);
      run_table_dump_query(p, zSelect, 0);
    }
    free(zSelect);
  }
  return 0;
}

/*
** Run zQuery.  Use dump_callback() as the callback routine so that
** the contents of the query are output as SQL statements.
**
** If we get a SQLITE_CORRUPT error, rerun the query after appending
** "ORDER BY rowid DESC" to the end.
*/
static int run_schema_dump_query(
  ShellState *p, 
  const char *zQuery
){
  int rc;
  char *zErr = 0;
  rc = sqlite3_exec(p->db, zQuery, dump_callback, p, &zErr);
  if( rc==SQLITE_CORRUPT ){
    char *zQ2;
    int len = strlen30(zQuery);
    fprintf(p->out, "/****** CORRUPTION ERROR *******/\n");
    if( zErr ){
      fprintf(p->out, "/****** %s ******/\n", zErr);
      sqlite3_free(zErr);
      zErr = 0;
    }
    zQ2 = malloc( len+100 );
    if( zQ2==0 ) return rc;
    sqlite3_snprintf(len+100, zQ2, "%s ORDER BY rowid DESC", zQuery);
    rc = sqlite3_exec(p->db, zQ2, dump_callback, p, &zErr);
    if( rc ){
      fprintf(p->out, "/****** ERROR: %s ******/\n", zErr);
    }else{
      rc = SQLITE_CORRUPT;
    }
    sqlite3_free(zErr);
    free(zQ2);
  }
  return rc;
}

/*
** Text of a help message
*/
static char zHelp[] =
  ".backup ?DB? FILE      Backup DB (default \"main\") to FILE\n"
  ".bail on|off           Stop after hitting an error.  Default OFF\n"
  ".binary on|off         Turn binary output on or off.  Default OFF\n"
  ".clone NEWDB           Clone data into NEWDB from the existing database\n"
  ".databases             List names and files of attached databases\n"
  ".dbinfo ?DB?           Show status information about the database\n"
  ".dump ?TABLE? ...      Dump the database in an SQL text format\n"
  "                         If TABLE specified, only dump tables matching\n"
  "                         LIKE pattern TABLE.\n"
  ".echo on|off           Turn command echo on or off\n"
  ".eqp on|off            Enable or disable automatic EXPLAIN QUERY PLAN\n"
  ".exit                  Exit this program\n"
  ".explain ?on|off?      Turn output mode suitable for EXPLAIN on or off.\n"
  "                         With no args, it turns EXPLAIN on.\n"
  ".fullschema            Show schema and the content of sqlite_stat tables\n"
  ".headers on|off        Turn display of headers on or off\n"
  ".help                  Show this message\n"
  ".import FILE TABLE     Import data from FILE into TABLE\n"
  ".indexes ?TABLE?       Show names of all indexes\n"
  "                         If TABLE specified, only show indexes for tables\n"
  "                         matching LIKE pattern TABLE.\n"
#ifdef SQLITE_ENABLE_IOTRACE
  ".iotrace FILE          Enable I/O diagnostic logging to FILE\n"
#endif
  ".limit ?LIMIT? ?VAL?   Display or change the value of an SQLITE_LIMIT\n"
#ifndef SQLITE_OMIT_LOAD_EXTENSION
  ".load FILE ?ENTRY?     Load an extension library\n"
#endif
  ".log FILE|off          Turn logging on or off.  FILE can be stderr/stdout\n"
  ".mode MODE ?TABLE?     Set output mode where MODE is one of:\n"
  "                         ascii    Columns/rows delimited by 0x1F and 0x1E\n"
  "                         csv      Comma-separated values\n"
  "                         column   Left-aligned columns.  (See .width)\n"
  "                         html     HTML <table> code\n"
  "                         insert   SQL insert statements for TABLE\n"
  "                         line     One value per line\n"
  "                         list     Values delimited by .separator strings\n"
  "                         tabs     Tab-separated values\n"
  "                         tcl      TCL list elements\n"
  ".nullvalue STRING      Use STRING in place of NULL values\n"
  ".once FILENAME         Output for the next SQL command only to FILENAME\n"
  ".open ?FILENAME?       Close existing database and reopen FILENAME\n"
  ".output ?FILENAME?     Send output to FILENAME or stdout\n"
  ".print STRING...       Print literal STRING\n"
  ".prompt MAIN CONTINUE  Replace the standard prompts\n"
  ".quit                  Exit this program\n"
  ".read FILENAME         Execute SQL in FILENAME\n"
  ".restore ?DB? FILE     Restore content of DB (default \"main\") from FILE\n"
  ".save FILE             Write in-memory database into FILE\n"
  ".scanstats on|off      Turn sqlite3_stmt_scanstatus() metrics on or off\n"
  ".schema ?TABLE?        Show the CREATE statements\n"
  "                         If TABLE specified, only show tables matching\n"
  "                         LIKE pattern TABLE.\n"
  ".separator COL ?ROW?   Change the column separator and optionally the row\n"
  "                         separator for both the output mode and .import\n"
  ".shell CMD ARGS...     Run CMD ARGS... in a system shell\n"
  ".show                  Show the current values for various settings\n"
  ".stats on|off          Turn stats on or off\n"
  ".system CMD ARGS...    Run CMD ARGS... in a system shell\n"
  ".tables ?TABLE?        List names of tables\n"
  "                         If TABLE specified, only list tables matching\n"
  "                         LIKE pattern TABLE.\n"
  ".timeout MS            Try opening locked tables for MS milliseconds\n"
  ".timer on|off          Turn SQL timer on or off\n"
  ".trace FILE|off        Output each SQL statement as it is run\n"
  ".vfsname ?AUX?         Print the name of the VFS stack\n"
  ".width NUM1 NUM2 ...   Set column widths for \"column\" mode\n"
  "                         Negative values right-justify\n"
;

/* Forward reference */
static int process_input(ShellState *p, FILE *in);
/*
** Implementation of the "readfile(X)" SQL function.  The entire content
** of the file named X is read and returned as a BLOB.  NULL is returned
** if the file does not exist or is unreadable.
*/
static void readfileFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  const char *zName;
  FILE *in;
  long nIn;
  void *pBuf;

  UNUSED_PARAMETER(argc);
  zName = (const char*)sqlite3_value_text(argv[0]);
  if( zName==0 ) return;
  in = fopen(zName, "rb");
  if( in==0 ) return;
  fseek(in, 0, SEEK_END);
  nIn = ftell(in);
  rewind(in);
  pBuf = sqlite3_malloc64( nIn );
  if( pBuf && 1==fread(pBuf, nIn, 1, in) ){
    sqlite3_result_blob(context, pBuf, nIn, sqlite3_free);
  }else{
    sqlite3_free(pBuf);
  }
  fclose(in);
}

/*
** Implementation of the "writefile(X,Y)" SQL function.  The argument Y
** is written into file X.  The number of bytes written is returned.  Or
** NULL is returned if something goes wrong, such as being unable to open
** file X for writing.
*/
static void writefileFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  FILE *out;
  const char *z;
  sqlite3_int64 rc;
  const char *zFile;

  UNUSED_PARAMETER(argc);
  zFile = (const char*)sqlite3_value_text(argv[0]);
  if( zFile==0 ) return;
  out = fopen(zFile, "wb");
  if( out==0 ) return;
  z = (const char*)sqlite3_value_blob(argv[1]);
  if( z==0 ){
    rc = 0;
  }else{
    rc = fwrite(z, 1, sqlite3_value_bytes(argv[1]), out);
  }
  fclose(out);
  sqlite3_result_int64(context, rc);
}

/*
** Make sure the database is open.  If it is not, then open it.  If
** the database fails to open, print an error message and exit.
*/
static void open_db(ShellState *p, int keepAlive){
  if( p->db==0 ){
    sqlite3_initialize();
    sqlite3_open(p->zDbFilename, &p->db);
    globalDb = p->db;
    if( p->db && sqlite3_errcode(p->db)==SQLITE_OK ){
      sqlite3_create_function(p->db, "shellstatic", 0, SQLITE_UTF8, 0,
          shellstaticFunc, 0, 0);
    }
    if( p->db==0 || SQLITE_OK!=sqlite3_errcode(p->db) ){
      fprintf(stderr,"Error: unable to open database \"%s\": %s\n", 
          p->zDbFilename, sqlite3_errmsg(p->db));
      if( keepAlive ) return;
      exit(1);
    }
#ifndef SQLITE_OMIT_LOAD_EXTENSION
    sqlite3_enable_load_extension(p->db, 1);
#endif
    sqlite3_create_function(p->db, "readfile", 1, SQLITE_UTF8, 0,
                            readfileFunc, 0, 0);
    sqlite3_create_function(p->db, "writefile", 2, SQLITE_UTF8, 0,
                            writefileFunc, 0, 0);
  }
}

/*
** Do C-language style dequoting.
**
**    \a    -> alarm
**    \b    -> backspace
**    \t    -> tab
**    \n    -> newline
**    \v    -> vertical tab
**    \f    -> form feed
**    \r    -> carriage return
**    \s    -> space
**    \"    -> "
**    \'    -> '
**    \\    -> backslash
**    \NNN  -> ascii character NNN in octal
*/
static void resolve_backslashes(char *z){
  int i, j;
  char c;
  while( *z && *z!='\\' ) z++;
  for(i=j=0; (c = z[i])!=0; i++, j++){
    if( c=='\\' && z[i+1]!=0 ){
      c = z[++i];
      if( c=='a' ){
        c = '\a';
      }else if( c=='b' ){
        c = '\b';
      }else if( c=='t' ){
        c = '\t';
      }else if( c=='n' ){
        c = '\n';
      }else if( c=='v' ){
        c = '\v';
      }else if( c=='f' ){
        c = '\f';
      }else if( c=='r' ){
        c = '\r';
      }else if( c=='"' ){
        c = '"';
      }else if( c=='\'' ){
        c = '\'';
      }else if( c=='\\' ){
        c = '\\';
      }else if( c>='0' && c<='7' ){
        c -= '0';
        if( z[i+1]>='0' && z[i+1]<='7' ){
          i++;
          c = (c<<3) + z[i] - '0';
          if( z[i+1]>='0' && z[i+1]<='7' ){
            i++;
            c = (c<<3) + z[i] - '0';
          }
        }
      }
    }
    z[j] = c;
  }
  if( j<i ) z[j] = 0;
}

/*
** Return the value of a hexadecimal digit.  Return -1 if the input
** is not a hex digit.
*/
static int hexDigitValue(char c){
  if( c>='0' && c<='9' ) return c - '0';
  if( c>='a' && c<='f' ) return c - 'a' + 10;
  if( c>='A' && c<='F' ) return c - 'A' + 10;
  return -1;
}

/*
** Interpret zArg as an integer value, possibly with suffixes.
*/
static sqlite3_int64 integerValue(const char *zArg){
  sqlite3_int64 v = 0;
  static const struct { char *zSuffix; int iMult; } aMult[] = {
    { "KiB", 1024 },
    { "MiB", 1024*1024 },
    { "GiB", 1024*1024*1024 },
    { "KB",  1000 },
    { "MB",  1000000 },
    { "GB",  1000000000 },
    { "K",   1000 },
    { "M",   1000000 },
    { "G",   1000000000 },
  };
  int i;
  int isNeg = 0;
  if( zArg[0]=='-' ){
    isNeg = 1;
    zArg++;
  }else if( zArg[0]=='+' ){
    zArg++;
  }
  if( zArg[0]=='0' && zArg[1]=='x' ){
    int x;
    zArg += 2;
    while( (x = hexDigitValue(zArg[0]))>=0 ){
      v = (v<<4) + x;
      zArg++;
    }
  }else{
    while( IsDigit(zArg[0]) ){
      v = v*10 + zArg[0] - '0';
      zArg++;
    }
  }
  for(i=0; i<ArraySize(aMult); i++){
    if( sqlite3_stricmp(aMult[i].zSuffix, zArg)==0 ){
      v *= aMult[i].iMult;
      break;
    }
  }
  return isNeg? -v : v;
}

/*
** Interpret zArg as either an integer or a boolean value.  Return 1 or 0
** for TRUE and FALSE.  Return the integer value if appropriate.
*/
static int booleanValue(char *zArg){
  int i;
  if( zArg[0]=='0' && zArg[1]=='x' ){
    for(i=2; hexDigitValue(zArg[i])>=0; i++){}
  }else{
    for(i=0; zArg[i]>='0' && zArg[i]<='9'; i++){}
  }
  if( i>0 && zArg[i]==0 ) return (int)(integerValue(zArg) & 0xffffffff);
  if( sqlite3_stricmp(zArg, "on")==0 || sqlite3_stricmp(zArg,"yes")==0 ){
    return 1;
  }
  if( sqlite3_stricmp(zArg, "off")==0 || sqlite3_stricmp(zArg,"no")==0 ){
    return 0;
  }
  fprintf(stderr, "ERROR: Not a boolean value: \"%s\". Assuming \"no\".\n",
          zArg);
  return 0;
}

/*
** Close an output file, assuming it is not stderr or stdout
*/
static void output_file_close(FILE *f){
  if( f && f!=stdout && f!=stderr ) fclose(f);
}

/*
** Try to open an output file.   The names "stdout" and "stderr" are
** recognized and do the right thing.  NULL is returned if the output 
** filename is "off".
*/
static FILE *output_file_open(const char *zFile){
  FILE *f;
  if( strcmp(zFile,"stdout")==0 ){
    f = stdout;
  }else if( strcmp(zFile, "stderr")==0 ){
    f = stderr;
  }else if( strcmp(zFile, "off")==0 ){
    f = 0;
  }else{
    f = fopen(zFile, "wb");
    if( f==0 ){
      fprintf(stderr, "Error: cannot open \"%s\"\n", zFile);
    }
  }
  return f;
}

/*
** A routine for handling output from sqlite3_trace().
*/
static void sql_trace_callback(void *pArg, const char *z){
  FILE *f = (FILE*)pArg;
  if( f ){
    int i = (int)strlen(z);
    while( i>0 && z[i-1]==';' ){ i--; }
    fprintf(f, "%.*s;\n", i, z);
  }
}

/*
** A no-oputine forata from FILE f( c=='v' ){ i--; g uolr
    "t tc- to FILr of erentback mpine atspoE or sCORRUdebuign k uolr
    void sql_trace_catest_ uolr
     cons_int64oleanValueng, ne{
    fng, n}
  o-oputine e. bjTextu if thiurned  CSVlly thger oached  out".shelvoid l_naMIT_r *zSuffrom FCtxffrom FCtx;
r *zSuffrom FCtxfint6zFile;

  UNUSED_Pf result tefile(Xnot awritin= applong nIn;rg);
  retypes *at of sCSVln"
  "ting derenot awr *eam*pzErrMsg           /* Useote ccumellStd\n"
  "  d  ft nAlloc = 0;               /*resues written is rin zlloc = 0;       ;       /*resSe off explain_d"  dzst cha = 0;  L FI* Tail of unprCs for v valutes wricha = 0; cTerm* Tail of unprC in octalE f( tring. Retuof smole;thisnt ft nAlloc = 0; cColSe          of the ator and optionalN in octath)\Usu\n"
 ",")lloc = 0; c
              of the  by d optionalN in octath)\Usu\n"
 "( zElloc}d refeA"ORDEl-terminatn is thizst chasql_trace_ca".shel_ "ORDE_N in(from FCtxfAlive){
='0' && c< 0;
+1>= 0;
   nAlloc +=  0;
   nAl+=  0;
   nAl+p->aiIndenme, alloc64( nI>aiIndent, nAz,  0;
   nA==0 ){
     nAz fprintf(stderr, "Error: cannoderrttease inp->writableS }
#ifndef SQLISQLISQ nAz[ 0;
++qlite3_co)Text of s *at -terminat current CSVln"
 .ratedpl_tdata' ){ rfc4180/
statitRDE   -> ' ){ i--;he rowon orav.  De d optionalora
    le.","a    -> al+ Argt aw toed  ting 0;
n. -> al+ AS of Dr       nt[] *zon owhig){  0;
.raSe offthihot su *zo toedd "Goto" _trace().
*/
n );
  if). -> al+ An plu *c   back routtor and optionar of byin\") fr
sta,"a    al+ An plu *r   back rou by d optionar of byin\") fr
stap->a    al+ AKe  bck(vktefile(X valutes wrint[] * L FI. -> al+ AS of D rout in octalE f( tring. Reses not urrent[] *cTerm. AS of d "Goto" EOF"
  RDE-of-names -> al+ AReom FIsyntaxge andn"
  or: cahar zHelp[] =
  *PT;
    DECLmma-I>aid_one_t urr(from FCtxfAl  if( zArcg = 0;
 c   b=  0;cColSe   = 0;
 r   b=  0;c
      ISQ nAne{
    f, 1, get, dum= sqlit){
    EOF"triceenrg asruptlloc +=  0;cTerm 1,EOF;0;
  }
  fprintf(stde{
        c = '"';inputc,  pe3_snprrray(cartL FIb=  0; L FI*_snprrraycQle naf( j<i =  , 1,ppse{
    r && z[i-11= z[++i];
     get, dum= sqlit ){
       r   b)  0; L FI    c = (c       cQle na   i++;
           cQle na   i++;
   =  , 1,      /* i];
    }

      /*     }
    z[j] =      (   c   bnsta   cQle n)    /*  tri(   r   bnsta   cQle n)    /*  tri(   r   bnsta   }elsbnstaa   cQle n)    /*  tri(   EOF"nsta   cQle n)    /* isplay_scanso{  0; rintf& z[i-1 nAz[ 0;
]! cQle na      /*    0;cTerm 1,c     /*    }
      sqlite3_stmt        cQle naretu! }elsbisplay_scanrr, "Error: canno%s:%dopenescanaM %cut in octa       iCur, iHiwtrSQ nAz
    i 0; L FI,ycQle n     nRow++;
    ){
    EOF"isplay_scanrr, "Error: canno%s:%dopentring. Retu%c-
    dot urr       iCur, iHiwtrSQ nAz
    i(cartL FI,ycQle n     nRow   0;cTerm 1,c     /*    }
      sqlite3_stmt .shel_ "ORDE_N in(livc     nRowppse{
pc     /* pse{
clse{
    while( IsDigit(zArgu! EOF"nstu! c   bnstu! r   b){e3_stmt .shel_ "ORDE_N in(livc     nRow     get, dum= sqlit )>db==0 ||    r   b){e3_stmt 0; L FI    c = (c     0; ==';'  nAz[ 0;
i--; }elsbi  0; rinlit )>db==0 0;cTerm 1,c    stde{
  u *zo)1 nAz[ 0;
] sqlite3_
  fpr nAzext of s *at -terminat current ASCIIy .separaton"
 .    -> al+ Argt aw toed  ting 0;
n. -> al+ AS of Dr       nt[] *zon owhig){  0;
.raSe offthihot su *zo toedd "Goto" _trace().
*/
n );
  if). -> al+ An plu *c   back routtor and optionar of byin\") fr
sta\x1F"a    al+ An plu *r   back rou by d optionar of byin\") fr
stapx1E>a    al+ AKe  bck(vktefile(X by tes wrint[] * L FI. -> al+ AS of D rout in octalE f( tring. Reses not urrent[] *cTerm. AS of d "Goto" EOF"
  RDE-of-names -> al+ AReom FIsyntaxge andn"
  or: cahar zHelp[] =
  *PT;
    DECLmter NI>aid_one_t urr(from FCtxfAl  if( zArcg = 0;
 c   b=  0;cColSe   = 0;
 r   b=  0;c
      ISQ nAne{
    f, 1, get, dum= sqlit){
    EOF"triceenrg asruptlloc +=  0;cTerm 1,EOF;0;
  }
  fprintf(stdeit(zArgu! EOF"nstu! c   bnstu! r   b){e3_st .shel_ "ORDE_N in(livc     nR, 1, get, dum= sqlitstde{
     r   b){e3_st 0; L FI    c LISQ nAcTerm 1,c    {
  u *zo)1 nAz[ 0;
] sqlite3_
  fpr nAzext of pen an outpck(nsftalLE int
  "    );

   not, tsage and isiceeneit(zApen mov.  Dfence *,pck outpgo*    ce *sr of by    ce *s movis runwon'a hexworknt
  WITHOUT ROWIDMS millvoid sql_trace_catryTonto N    te *p, 
  const ch
b,         newDb,nt6zFile;

  UNU

   3_stmt *pStmt = NULL;rc =  sqli tmt *pStmt = NULL;       {
    f,){
  int rc {
    f,){
  i       {
    far *zErr =char c;
, nrr =charng[0];
  z);
    while
    frr =chark {
    far *   }

     zFile;rray(pinRa naf(,
  }PARAMint rc {
ntf("EXPLAIN QUERRT INTO*;
    \"%w\"0 ){
    fite3_prepare_v2(p->db, zTableInfo, -callbacnfo, 0callbac0=SQLITE_CORntf(p->out, "ANAor: cannot ope % zExp"
  [%s]       iCur, iHiw(p->db, zQtRDE  db) ){
      fprmsg(p->db));
      if(    iCur, iHiw rc = sqlite3go*/
 DE_pArg)xfwhile(LISQn lumn_count(pStmt);
     rc = sqliti       {
e().
*/
n );
  if20- '0ng[0];
'0n*30 ){
    r      printf(p->out, "ANAor: cannoderrttease inp->writablgo*/
 DE_pArg)xfwhile(LISQintf(len+100, zQ220-+ng[0];,r                        wri sqlite_OR IGNORE" ... File); ", 0);
?0 ){
    fite3len(z);
    while      fite3g[i]j=1; j<n;f( c=='\\' asecpyle      +i   }?0 )2==0 ){
 hile( (x LISQasecpyle      +i     rc 3fite3_prepare_v2(p->db, zTablnewDb, r      acnfo, 0      ac0=SQLITE_CORntf(p->out, "ANAor: cannot ope % zExp"
  [%s]       iCur, iHiw(p->db, zQtRDE  db) ){
  newDbprmsg(p->db));
   newDbpr   iCur, iHiw rc = sqlite3go*/
 DE_pArg)xfwhile(LISQmx; k++){
 2double rEstLhexDigit_step(pTableInfo);
rc = sW ){
            fprintCol; i++){
             aiTyswitch(umn_count(pStmt)i);
  callbaci           rc = keyw ){
       : {   iCur, iHiw(p->db, biDE_RING(0      aci+  if( !pData )   }
      sqliiiii}       rc = keyw ){
    ..EGER: {   iCur, iHiw(p->db, biDE_t, rc)0      aci+ lumn_int(pExplain, 2rc)0callbai    fprintf(pArg }
      sqliiiii}       rc = keyw ){
   FLOAT: {   iCur, iHiw(p->db, biDE_;
    )0      aci+ lumn_int(pExplain;
    )0callbai    fprintf(pArg }
      sqliiiii}       rc = keyw ){
   TEXT: {   iCur, iHiw(p->db, biDE_nfo, 1      aci+ l                 wriiiiiiiiiii)sqlite3_column_text(pSql, 1);

  callbai l                 wriiiiiiiiiii-F8, 0,
   , (vIC   fprintf(pArg }
      sqliiiii}       rc = keyw ){
   is r: {   iCur, iHiw(p->db, biDE_);
  0      aci+ lumn_int(pExplain);
  0callbai l                 wriiiiiiiiiiiiiiiiiiiiiiiiiimn_int(pExplain)), ou0callbai l                 wriiiiiiiiiiiiiiiiiiiiiiiiii 0,
   , (vIC   fprintf(pArg }
      sqliiiii}       rc  }
    zg wri          }
    _step(pTableInfo);
      fite33333TE_OK || nRow==0 )nstK || nRow==    nstK || nRow==DONE"isplay_scanrr, "Error: cannot ope % zExp_column_text(zQtRDE  db) ){
  newDbpr                 wriiiiiisg(p->db));
   newDbp     nRow++;
    lt_int64(coet;
      fite33333       c = (c    (   %(pinRa n)   rEstLoop = (AIN QUER%c\bad",|/-\\"[(   /(pinRa n)%4]   fprintf(fflush(lse if     nRow++;
  zg wri   return rc3333TE_OK =| nRow==DONE"ig }
      sqlize(pTableInfo);
rc = sqlite3(zErr);
    frrc = sqlite3int rc {
ntf("EXPLAIN QUERRT INTO*;
    \"%w\"wid DESC", zQuery);
;                            sqli{
    fite3e3_prepare_v2(p->db, zTableInfo, -callbacnfo, 0callbac0=SQLI      fprintf(p->out, "/**or: cannoWartabln \"%s\"\nfo) File);     ce *s0 ){
    fite33333
  }
  return isg wri       k++...Elloc
 DE_pArg)xfwh:
sqlize(pTableInfo);
rc = sqlitlize(pTableInfo);
      fite3(zErr);
    frrc = sqlit(zIns);
    retur   fitis is a difn outpck(nsftal, need bygs in th?     E f(   "   zW onebe so retueived byive)voke xso eive()ent mode bjTextdebleallback a/
   .t a SQLsage and isienrequiree  returnmov.  Dfence *ck roug{ i--the s(type,name,tMS mil,pck oag    mov.  D    ce *sroid sql_trace_catryTonto N    }
te *p, 
  const ch
b,         newDb,nt6zFile;

  UNUW one,nt6ce_ca(*xso eive)*p, int kee*,       *,sqlite3_colu3_stmt *pStmt = NULL;rc =  sqli  f,){
  int rc {
    fnst char *zTableunss.  (Se  FILE *in;
  zTableunss.  (Se  FILE char *z0;
  rc =rr_msg}PARAMint rc {
ntf("EXPLAIN QUERRT INTO3_errmsg(_sequence;\n"name,t"                          sq" WHERE"%s0 ){W onefite3_prepare_v2(p->db, zTableInfo, -callbacnfo, 0callbac0=SQLITE_CORntf(p->out, "ANAor: cannot ope: (%d)Exp"
  [%s]       iCur, iHiwwriiiiiisg(p->db)QtRDE  db) ){
      fprmsg(p->db));
      if(    iCur, iHiw    sqli{rc = sqlite3go*/
 DE_query(
xfwhile(LISQhexDigit_step(pTableInfo);
rc = sW ){
            fprist char*mn_text(pSql, 1);

  callbalect = appeqcolumn_count(pStmt));

  callbal  if( !pAIN QUER%slumn0 ){t ch);(fflush(lse if     nR(p->db, zQ2, newDb, )sqlite3_coluE VIRT0RT0RT&rc =rr_Err ){
      fp   *pzErrMsg ut, "ANAor: cannot ope: xp_c{
 : [%s]       fp   ,  }

      /* (zErr);
    free(rr_Err ){
  rc =rr_msg}PAreturn iack(pArso eive*pzErrMsg xso eive(p, newDb, )sqlite3_coluEt ch);Areturn iacAIN QUERdo     sqlitstde{
  K || nRow==DONE"isplay_lize(pTableInfo);
rc = sqlite3(zErr);
    frrc = sqlite3int rc {
ntf("EXPLAIN QUERRT INTO3_errmsg(_sequence;\n"name,t"                          sqsq" WHERE"%swid DESC", zQuery);
    W onefite3e3_prepare_v2(p->db, zTableInfo, -callbacnfo, 0callbac0=SQLI      fprintf(p->out, "/**or: cannot ope: (%d)Exp"
  [%s]       iCur, iHiwwriiiiiiiisg(p->db)QtRDE  db) ){
      fprmsg(p->db));
      if(    iCur, iHiw    sqlili{rc = sqlite3e3go*/
 DE_query(
xfwhile(turn iachexDigit_step(pTableInfo);
rc = sW ){
            fprintst char*mn_text(pSql, 1);

  callbalect = apappeqcolumn_count(pStmt));

  callbal  if( !p!pAIN QUER%slumn0 ){t ch);(fflush(lse if     nRnR(p->db, zQ2, newDb, )sqlite3_coluE VIRT0RT0RT&rc =rr_Err ){
{
      fp   *pzErrMsg g ut, "ANAor: cannot ope: xp_c{
 : [%s]       fp   ,  }

      /* * (zErr);
    free(rr_Err ){
    rc =rr_msg}PAretuow++;
    ){
 rso eive*pzErrMsg g xso eive(p, newDb, )sqlite3_coluEt ch);Aretuow++;
    AIN QUERdo     sqlitSQLISQLI DE_query(
xfwh:
sqlize(pTableInfo);
rc = sqlitlize(pTab   frrc = sqlt of pen Ot fil newils to openis read an"zNewDb". ifn outpnd dvtal,s m unaabout the dback sth suffi fileygs in t FILils to ope(hexunam NULLbouttsrupt creatwry data hex  ThezNewDbroid sql_trace_catryTonto N*p, int keepAlivzName;
  FILE ewDbp if( zArchar *         newDbzArg[0]=='-'a. */
(E ewDb,0fprintf(p->out, "ANAor: cannot chaFile); al>aidy unreas.       ewDbp;0;
  }
  fpqlitstde_step(pTableI"rb");
ewDb, &newDbp;0;
TE_CORntf(p->out, "ANAor: cannoC"%s\"\able.
*sqlite3ls to opzExp_col   iCur, iHiw(p->db, ));
   newDbp     qlite3_free(pBuf);
zQ2, dump_caable_schema=ON;\n");
      "RT0RT0RTte3_create_functzQ2, newDb, "BEGIN EXCLUSIVE "RT0RT0RTte3_creatryTonto N    }
tp, newDb, "i);
=,'%q',0",atryTonto N    e3_creatryTonto N    }
tp, newDb, "i);
!=,'%q',0",ate3_create_functzQ2, newDb, "COMMIT "RT0RT0RTte3_create_functzQ2, dump_caable_schema=ON;\n");
    FF "RT0RT0RTte3_crLISQintf(len
/*
**newDbp;0se an outplumn separ   The nameD     or stic void output_file_close(F(coet;p){
  sqlite3_free{
  u *clonamezArg[1|sbispTE_OMIT_LOAD_EXTENSIPOPE3_enabp
/*
**u *clo  sqlite3_crqlite3_freeclose(FILE *f){
  u *clo  sc LISQ nAclonamezArzArg[0]= nAclo }else if(  zQuery.  Useformat\ to FILE as a BLOB in thrminate if appr     int dump_callbackbn, 2)p, int keepAlivzName;
  FILE}

 stmt *pStmt = NULL;  pArg-> zArc&azVa0qlitlize(pTa->db, zTableInfo, -Smt, &zLeftover);0=SQLITE_CETE FRrrcode(p->d
           ){
            fpric&azVamn_int(pExplain, 2       te3_crLISQintf(lenmt);
      if( rc!=

/*
** es;0se an outpon
** il 2-n is nd 4-n is big-liter a boolean  Thel n right booleant dunss.  (S zArget2n isI 2 unss.  (Se  FILa   fp(integerazAr<<8 zAra= azA}dunss.  (S zArget4n isI 2 unss.  (Se  FILa   fp(integerazAr<<2  zAr(a= a<<16 zAr(a=2r<<8 zAra=3]mplementation of the "writefile(X,.abou"\ to FIL.    -> 0
** for Tnn the qu2 */
  it/
    0lora
 ql tint dump_callbacunc, _      _ to FIL*p, int keepAlive){
*azArg, char **azC_int64oleanV { char *zSuffixName;
  FILE *in;ve){
ofs = {
 F urr "KiB", 1020000nameDalue ofrequire:000 24 ",   1000000ls to ope    frequi:000 28 ",   1000000b   match    frequi:000 36 ",   1000000h?     cookie:000       40 ",   1000000h?     out th:000       44 ",   1000000ln\") frcses\ *));:000  48 ",   1000000PLAIvacuum tta froh:000 52 ",   1000000inabl the l vacuum:000  64 ",   1000000n"
  enreER B:000       56 ",   1000000usapprer1);
:000        60 ",   1000000aack c "writid:000      68 ",   1000000softws SQrer1);
:000    96 ",   1  int4oleanV { char *zSuffixName;
  FILE *in;vzSql;
  const cha {
 rc =  "KiB", 1020000tes writteS mill:ol   iCur,RRT INTO;
    *)_sequexp"WHERE"i);
=,'%q',0"",   1000000tes writtetables\:ol   iCur,RRT INTO;
    *)_sequexp"WHERE"i);
=,table0"",   1000000tes writtetriign l:ol   iCur,RRT INTO;
    *)_sequexp"WHERE"i);
=,'riign 0"",   1000000tes writteviewl:ol   iCur,RRT INTO;
    *)_sequexp"WHERE"i);
=,view0"",   1000000h?     *));:00   iCur,RRT INTOtoe l(whig){(int))_sequexp"",   1  int4ntf(lenmturn pSED_PAf( zArg[0]=  const ?    Tab[0]=  constDbzAr*azA>=2 ? zSql = a : m FILf( squnss.  (Se  FIaHdr[10= azArlState *p);0=SQLITE_CE   sqlite }
  if( sqli4ntf(lenmturntextrolleInfo, -Db,  ){
   FCNTL_longIPO ..ERLeft
  }
  reTE_CEturn;
  ||CEturn->pMethods;
  ||CEturn->pMethods->x *ateturn 1;
  }
  if( sqlite3_sb=  turn->pMethods->x *at(p
    iaHdr10240);0=SQLITE_Ci!{
      sqlite3_crut, "ANAor: cannoen databasurnedls to oper off\   sqlitSQ}
  if( sqlite3_sb= get2n isI 2 aHdr+16 SQLITE_Ci==1te sb= 65536SQLIut, "%s;\n", zSql)-20s %r    00ls to ope    f*));:000      ut, "%s;\n", zSql)-20s %r    00wry daout th:000aHdr[18]     ut, "%s;\n", zSql)-20s %r    00urnedout th:000aHdr[19]     ut, "%s;\n", zSql)-20s %r    00ursapcallbats\:ol0aHdr[2File==0rraySize(aMult); i++){F urr if( sqlite3_s){
ofs t(zSF urr i].ofs =ite3_unss.  (S zArvalb= get4n isI 2 aHdrzArofs sqlitSQut, "%s;\n", zSql)-20s %uol0aF urr i].;
  if(vale3_creatwitch(uofs t z[++i];
  ope56: {   iCur, TE_Cval==1te ut, "%s;\n", zSql (lon8)"    /* save TE_Cval==2te ut, "%s;\n", zSql (lon16 }
"    /* save TE_Cval==3te ut, "%s;\n", zSql (lon16b}
"    /* savz[j] = c;
  ut, "%s;\n", zSql   sqlitstde{
  -DbPrepStmt = " ?    Tab {
ntf("EXPLAIN QUER FIL.nce;\n"name,t"     qlitezFile, "off")Db,0n"mp zPrepStmt = " ?    Tab {
ntf("EXPLAIN QUER%s0 ))==0 ){
n"mp"name,t"     qlitetmt = " ?    Tab {
ntf("EXPLAIN QUER\"%w\".nce;\n"name,t", -Dbose(out);
raySize(aMult); i++){rc = sqf( sqlite3_  const ch {
ntf("EXPLAIN QUE rc =  zArg)mt, " ?    Tab=SQLI   zArvalb= kbn, 2)p,  }

      /lize(pTab   frSintf(p->out, "%s\n", zIns);-20s %r    0 rc =  zArg
  if(vale3_crLISQintf(lenm   frS?    Tab=SQLI
/*
** Close mentatiofor a bThe  valubegi='v' ){ "."t.  Ife)voke tshould printtotatit(Shellck a/
l FI. -> -> 0
** for Tnn the qu2 */
  it/
    0lora
 ql tint dump_callbacdo_meta_ to FIL*  constL FI,yp){
  sqlite3_free{aluerg++;
  e){
*azA {
    fnst n,rcg = 0;
 lse{
    re  FILaSql =5= az
  of Parseile(Xnot aw valu  Thetokens.
   rc33hexDigitL FI[hs[i]!*azAMult); i++){ffffffe rEstLhexDigi[0]) ) zSL FI[hsffe  h++;urn iack(pASL FI[hsqlite 
  }
  retuk(pASL FI[hsql    c||CSL FI[hsql   c = '"';
 lbacd.sep    L FI[h++ c=='a' )aSql =n
  }
"KiB&SL FI[hsc=='a' )hexDigitL FI[hs[i]!tL FI[hs!=d.sep         /* ck(pASL FI[hsql  !=0 ){d.sepql   ci]!tL FI[h    c =  h++;     /* ch++;u /* savz[j] = ck(pASL FI[hsqld.sep        /* c L FI[h++ msg}PAretuow++;
    ){
 d.sepql   c)kslashes(char *z){
  aSql =n
  -1]   fpri rc = SQLITE_aSql =n
  }
"KiB&SL FI[hsc=='a' )hexDigitL FI[hs[i]!![0]) ) zSL FI[hsffe  h++;urn iac ck(pASL FI[hs
}

L FI[h++ msg}PAretuowslashes(char *z){
  aSql =n
  -1]   fpri 
lect = of P(Shellck (Xnot aw val.
   rc33) returnqlite }
  if(0r */
nhetokens,
nhee and  rc33(zQuery);
   zType =    fpse{
zType =  = azAr    (      ci]!*>=3trrco "CREATzType = ns)FILE    0nzPre)    tri(   's ci]!*>=3trrco "CREATzType = ns)      0nzPre)   qlite3_ Sql;
  constDestt char**zTmp = Sql;
  constDbar**zTmp =         pDest     /lize(pTaFILE   *pefaultSQLI   zArjf(p->ou[i]j=1; j<n ){
f( c=='\\'  = Sql;
  conste{
zType j c=='a' ){
  z    isNeg = 1;
 a' )hexDigit    isNeg i=j=0; (((((((resuo;he rowrint t(Shellcaam\n"
 off\    }
      {   iCur, iHut, "ANAor: cannoenknown;he rowzExp_coluzType j    fprintf(pA  }
    zSelectuow++;
    rg[0]=='+' Destt ch   rEstLoop = (tDestt char*zType j c=='a' )rg[0]=='+' Db   rEstLoop = (tDbar*tDestt ch;tLoop = (tDestt char*zType j c=='a' )rg[0]zErrMsg g ut, "ANAor: cannotoo  FIy** is wrirint  FILE  p->writableSpA  }
    zSelectuz[j] = c;
  ='+' Destt ch   rEstLoop =ut, "ANAor: cannomishrmi      Exec* is writTnn FILE  p->writableS  }
    zSelect = ap='+' Db   rE(tDbar*m FILf( sqde_step(pTableI"rb");Destt chLeftDest=SQLI      fp!{
      sqlite3_crderr, "Error: cannot open \"%s\"\n", zFile);
    }Destt ch     nRnR(p->db, f){
  uDest=SQLI  eS  }
    zSelect = aplState *p);0=SQLIite3ILE   =/lize(pTaFILE  );
   uDest,*m FILf, eInfo, -Db==0 ){
     3ILE   fprintf(stderr, "Error: cannot open xp_column_text(z);
    Dest=     nRnR(p->db, f){
  uDest=SQLI  eS  }
    zSelect = aphexDigiit_step(pTableIFILE  )
     3ILE  ,240) ){
      sqlit3_free(zErr);
FILE  )f;
 sh  3ILE  =SQLI      fp=| nRow==DONE"isplay_scr, 1,      /rg[0]zErrMsg rr, "Error: cannot open xp_column_text(z);
    Dest=     nRnRr, 1, zSelect = ap(p->db, f){
  uDest=SQLIrg[0]mp(zType      ci]!*>=3trrco "CREATzType = ns)FIil  0nzPreb){e3_st  returnql2"isplay_scFIil_on_e and =e(char *zArg){zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:            Sp->writableS , 1, zSelect = rg[0]mp(zType      ci]!*>=3trrco "CREATzType = ns)F on o  0nzPreb){e3_st  returnql2"isplay_sc  re(char *zArg){zSql = a rEstLoop = (setB on oM{
      if     nRow+g[0]zErrMsg g setlp mM{
      if     nRow+ fpri rc = SQLITE_rr, "Error: cannoUt.
*:            Turp->writableS , 1, zSelect = rg[0]mp(zof the undocs wri an"g uolr
    "t to FILEcau    autine
*/
statorata
 it ild printead antest_ uolr
     ).
   rc33) re      ci]!*>=3trrco "CREATzType = ns)Fuolr
    " 0nzPreb){e3_sttest_ uolr
     )SQLIrg[0]mp(zType    c'trrco "CREATzType = ns)       0nzPreb){e3_st  returnql2"isplay_sctryTonto N*p, zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:          ".restorewritableS , 1, zSelect = rg[0]mp(zType    d ci]!*>1trrco "CREATzType = ns)
  ".dbin  0nzPreb){e3_stp){
  sqlit
  "zTmp = 0;
  rc =rr_msg}PA= aplState *p);0=SQLIitasecpyl&
  "
    *));of(
  "=     nR
  "     H off\ 1, zSelec
  " port\= of:\_ delimzSelec
  " colWcoluzArzAr3zSelec
  " colWcoluz1rzAr15zSelec
  " colWcoluz2rzAr58zSelec
  " cntar**zTmp =       tzQ2, dump_caable_sch
  ".dbi_matc;n0 ) &zErr);
 &
  "
 &rc =rr_Err ){
      fp   *pzErrMsg ut, "ANAor: canot open xp_coluree(rr_Err ){
  (zErr);
    free(rr_Err ){
   , 1, zSelect = rg[0]mp(zType    d ci]!o "CREATzType = ns)
       0nzPreb){e3_st_step(nc, _      _ to FIL*p, nazArgaurn 0;
}
rg[0]mp(zType    d ci]!o "CREATzType = ns)
ump  0nzPreb){e3_stlState *p);0=SQLIitof W  Ifge t.  D     au)
ump  0of sqlite_stm NULLe pureext foror: cQLIithexwexunacau    imd atic ou[ieign:  I= Sql;rFILt ascii,
viollStd.QLIithexSoomatic EXu[ieign-  I= Sql;rFILt eboutcis runnt t(ppeaput(Sc Ems.n rc3333TE_OnazA!=1[i]!*azA!l2"isplay_scrr, "Error: cannoUt.
*:   ...   TAB-PATTERN?orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = aput, "%s\n", zIns)ble_schu[ieign_  Is  FF orewritablut, "%s\n", zIns)BEGIN TRANSAC**** orewritabln",ema=ON;\S?    ar**zTmp =       tzQ2, dump_caaSAVEPO .. matc; ble_schema=ON;\n");
     "RT0RT0RTte3_crea 0;
 }
    zQ2 =   returnql1= z[++i];
ump_query(
  ShellStatp p->zDbFileRRT INTO3_errmi);
rmsg(_sequence;\n"name,t "         "WHERE"sg(_NOTurned AND"i);
==,'%q',0 AND"3_er! 'sce;\n"sellSnce'"       writableS mp_query(
  ShellStatp p->zDbFileRRT INTO3_errmi);
rmsg(_sequence;\n"name,t "         "WHERE"nurn;
'sce;\n"sellSnce'"       writableS mp_uery(p, zSelect, 0)->zDbFileRRT INTOsg(_sequence;\n"name,t "         "WHERE"sg(_NOTurned AND"i);
 IN (,table0,,'riign 0,,view0)"RT0       writabl rc = SQLITE_ zArg[0]=tabluraySi1+){
  ){
f          aiTyzp){
  sqlise{
zType ( c=='a' )eS mp_query(
  ShellStatp  fprintf(pARRT INTO3_errmi);
rmsg(_sequence;\n"name,t "           "WHERE"tbl_".
*/ TABLunc, 0, 0);() AND"i);
==,'%q',0"           "  AND"sg(_NOTurned>writableSpA mp_uery(p, zSelect, 0)->zDbFileleRRT INTOsg(_sequence;\n"name,t "           "WHERE"sg(_NOTurned"           "  AND"i);
 IN (,table0,,'riign 0,,view0)"           "  AND"ibl_".
*/ TABLunc, 0, 0);()"RT0        a      /*   zp){
  sqlise{
}PAretuow++;
  >db==0 || SQLema=ON;\S?    aisplay_scrr, "Errn", zIns)ble_schema=ON;\n");
    FF orewritableSn",ema=ON;\S?    ar**zTmp =t = ap(p->db, zQ2, dump_caable_schema=ON;\n");
    FF "RT0RT0RTte3_crap(p->db, zQ2, dump_caaRT IASE matc;"RT0RT0RTte3_craprr, "Errn", zIns 0;
 }
 ?aaROLLBACK; -- matabase andnore : mCOMMIT    sqlitsg[0]mp(zType    e ci]!o "CREATzType = ns)ff\n  0nzPreb){e3_st  returnql2"isplay_sc 0;ff\nOn =e(char *zArg){zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:            TorewritableS , 1, zSelect = rg[0]mp(zType    e ci]!o "CREATzType = ns)fqp  0nzPreb){e3_st  returnql2"isplay_sc 0;PLAIEQP =e(char *zArg){zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:            orewritableS , 1, zSelectlec = rg[0]mp(zType    e ci]!o "CREATzType = ns)f it  0nzPreb){e3_st  return>1trrct_stepz);
 izArg) & 0xffzSql = a ) c =   }
#irc     nR_step2qlitsg[0]mp(zType    e ci]!o "CREATzType = ns)fff?     0nzPreb){e3_st zArvalb= *azA>=2 ? (char *zArg){zSql = a r:, zSelecTypvalb=1, ) {   iCurTyp! 0;
ut tlM{
 .valid) {   iCur,  0;
ut tlM{
 .valid 1, zSelece3,  0;
ut tlM{
 .port\=  0;portzSelece3,  0;
ut tlM{
 .    H off\ 1, 0;    H off\zSelece3, asecpyl 0;
ut tlM{
 .colWcolu, nAcolWcolu,*));of( nAcolWcolup     nRow++;
    of W freqt suuam\n"
 ){
  undeQL com! 0;fff?   Valid+;
    hex.timi"writsock a/
itist or is un FILENif w
** e al>aidy in+;
    hexoff?    port. Howppeannalways un FILt stder );
ws u valueasy+;
    hexwasabasursCOR*/
  f?    portext   ope comusappt(pps\n"ly+;
    hexdion li|off?    fo);
wallbaca  "    , .port\or off    +;
    hex.to FIL. ;
    h/play_sc 0;port\= of:\_Eff?   ritableSn",    H off\ 1, zSelec, aseoet;
nAcolWcolu,0,*));of( nAcolWcolup     nRow nAcolWcoluzArzAr4             /*    of addr h/play_sc 0;colWcoluz1rzAr13             /*   of op){
  h/play_sc 0;colWcoluz2rzAr4             /*    of P1 h/play_sc 0;colWcoluz3rzAr4             /*    of P2 h/play_sc 0;colWcoluz4rzAr4             /*    of P3 h/play_sc 0;colWcoluz5rzAr13             /*   of P4 h/play_sc 0;colWcoluz6]tep2q            /*    of P5 h/play_sc 0;colWcoluz7rzAr13             /*   unprCto eapuh/play_rg[0]==' ( 0;
ut tlM{
 .valid) {   iCur 0;
ut tlM{
 .valid 1,0;play_sc 0;port\=  0;
ut tlM{
 .portritableSn",    H off\ 1, 0;
ut tlM{
 .    H off\zSelec, asecpyl 0;colWcolu, nA
ut tlM{
 .colWcolu,*));of( nAcolWcolup     nRt = rg[0]mp(zType    f ci]!o "CREATzType = ns)fu, 0);
    0nzPreb){e3_stp){
  sqlit
  "zTmp = 0;
  rc =rr_msg}PA= aplbacdoSff\n"   zQ2 =   return!l1= z[++i];
rr, "Error: cannoUt.
*:  fu, 0);
  orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = aplState *p);0=SQLIitasecpyl&
  "
    *));of(
  "=     nR
  "     H off\ 1,0zSelec
  " port\= of:\_Semi    nR_step(p->db, zQ2, dump_cSelece3,RRT INTOsg(_sequ"        "h)\nT INTOsg(_smt, i);
 i);
rmibl_".
*/ibl_".
*, VFS s".
*,  zQuerx"        "h))))sequence;\n"name,t UN*** Aed"        "h))nT INTOsg(, i);
rmibl_".
*,s".
*,  zQuersequence;\n"n"mp"name,t) "        "WHERE"i);
! 'meta' AND"sg(_NOTrned AND"VFS sNOTu TABL'sce;\n"%' "        "id DESC", zQue00   iCur, &zErr);
 &
  "
 &rc =rr_   iC=SQLI      fp=| nRow==sqlite3_create_funct= NULL;  pArg->  nR_step(p->db, ->db, zTableInfo,           ece3,RRT INTO zQuersequence;\n"name,t"                " WHERE"VFS sGLOBL'sce;\n"0, 0[134]'     iCur, iHiwwri&zLeftover);0=SQLIelec
oSff\n"  ode(p->d
           ){
        rr ){
  (zErr);
 t);
      if( rc!=  >db==0 || 
oSff\n fprintf(stderr, "Errn", zIns)resuo;, (vMS milliavailic EX*/   sqlitSQLrc = SQLITE_rr, "Errn", zIns)ANALYZEence;\n"name,t orewritableS       tzQ2, dump_caaST INTO'ANALYZEence;\n"name,t'     iCur, iHiwwriCur, &zErr);
 &
  "
 &rc =rr_=SQLIelec
  " port\= of:\_tur   SQLIelec
  " }Destg[0];
  "sce;\n"0, 01"ritableS nc, _zQ2, dump_caaST INTO*rsequence;\n"0, 01"    iCur, iHiwwriCu nc, _ &zErr);
 &
  "
&rc =rr_=SQLIelec
  " }Destg[0];
  "sce;\n"0, 03"ritableS nc, _zQ2, dump_caaST INTO*rsequence;\n"0, 03"    iCur, iHiwwriCu nc, _ &zErr);
 &
  "
&rc =rr_=SQLIelec
  " }Destg[0];
  "sce;\n"0, 04"ritableS nc, _zQ2, dump_caaST INTO*rsequence;\n"0, 04"    iCur, iHiwwriCu nc, _ &zErr);
 &
  "
 &rc =rr_=SQLIelecrr, "Errn", zIns)ANALYZEence;\n"name,t orewritablt = rg[0]mp(zType    h ci]!o "CREATzType = ns)ff    n  0nzPreb){e3_st  returnql2"isplay_sc 0;    H off\ 1,(char *zArg){zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:  ff    n      TorewritableS , 1, zSelect = rg[0]mp(zType    h ci]!o "CREATzType = ns)fflp  0nzPreb){e3_stut, "%s\n", zIns);s0 ){Hflpsqlitsg[0]mp(zType    i ci]!o "CREATzType = ns) .shel  0nzPreb){e3_st

  UNU

                /* /zArg     LE in  Thetn"
 oic EX*/e3_st

  UNUSED_Pf            /* /zAult tefimturn*/
  trasqlite_st_trac*/e3_stte_funct= NULL;  pA 1,rnedr */
As it is run rc3333Tluengol             /*   u*resues writteExplai  nt[ comoic EX*/e3_stTluenByt_Pf            /* /*resues written is rin format\,"no st*/e3_stTlue c;
             /*   u*resLoopfrequiresX*/e3_stTlueneedCto itz      /*   u*resTratabasCOMMIT\or ROLLBACKcaamRDEl*/e3_stTluen                  /* /*resues written is rin  nAcolS optionast cha = 
  const cha            /* /*resAormat\,"t is run rc3333from FCtxfsCtx;        /* /*resR off\ text,
  iha = 
  cons(PT;
    DECLm*x *at)(from FCtx*)r */

  }abasurned    
){
  F/e3_stTlue(PT;
    DECLm*xput fr)
  if( ; /* /*res
  }abasf){
 writin= aQ2 =   return!l3= z[++i];
rr, "Error: cannoUt.
*:   .shelplong TABLtorewritableSgo*/
meta_ to FIL_  itzSelect = apzt char*zType 1 c=='a'zg[0];
  zType 2 c=='a'ceenrg asruptl1,0zSelecaseoet;&sCtxRT0RT*));of(sCtx=     nRlState *p);0=SQLIitn   b= ery);
    nAcolS optiona=SQLI      n    fprintf(stderr, "Error: cannot open non-RING ator and optionalrequirn_d"  d .shelp->writableS  }
    zSelect = ap='+'n   >1= z[++i];
rr, "Error: cannot open multi-t in octalator and optionadigit.
);
wal"                       "d"  d .shelp->writableS  }
    zSelect = apn   b= ery);
    nAr     ptiona=SQLI      n    fprintf(stderr, "Error: cannot open non-RING  by d optionalrequirn_d"  d .shelp->writableS  }
    zSelect = ap='+'n   ql2";'  nAport==of:\_ svci]!o "REAT nAr     ptiona,)nTP_CrLf)   rEstLoop =of W  If .shelo stCSVl(only),ut 
** f by d optionalisicet
*/
sta+;
    hexdn\") fr   The  by d optiona,Dalue ofit
*/
stayin\") fr
ot a ;
    hex by d optionar of iliavoidsorav.  D*/
mFILtFILiliffefor v
ot a ;
    hexly th  The  by d optionas.n rc3333SQintf(len+100, zQ2*));of( nAr     ptiona=ns 0;r     ptiona,)nTP_RowwritableSn   b= ery);
    nAr     ptiona=SQLI  t = ap='+'n   >1= z[++i];
rr, "Error: cannot open multi-t in octal by d optionasigit.
);
wal"                       "d"  d .shelp->writableS  }
    zSelect = apsCtx.zt char*zt ch;tLoopsCtx.nL FIb=  zSelecTyppsCtx.zt chzArg[1|sbispTE_MIT_LOAD_EXTENSIPOPE3_enab;
rr, "Error: cannot open piplliareor stdupshel (S zetn"
 OSp->writableS  }
    zS#g[0]m3333SQiCtx.in =ep"rb")sCtx.zt ch+ lu"rewritableS Ctx.zt char*"<pipl>"ritableSxput fr =epf){
  sqlite3_crea rc = SQLITE_iCtx.in =ef"rb")sCtx.zt chlu"rbewritableSxput fr =eff){
  sLI  t = ap='+' nAport==of:\_Aer NNpzErrMsg x *at =mter NI>aid_one_t urr  fpri rc = SQLITE_x *at =mma-I>aid_one_t urr sLI  t = ap='+'iCtx.in fprintf(stderr, "Error: cannot open \"%s\"\n", zFile);
    }
  }
  retueS  }
    zSelect = apsCtx.cColSe  1, 0;colS optionas0];tLoopsCtx.c
      1, 0;r     ptionas0];tLoopt ch {
ntf("EXPLAIN QUEaST INTO*rseque%s0 ){
    fite333      ch fprintf(stderr, "Error: cannot open derrttease inp->writableSxput fr(iCtx.inwritableS  }
    zSelect = apnByt_b= ery);
   rSintf(p->o_prepare_v2(p->db, zTableInfo, -Smt, &zLeftover);0=SQLIst .shel_ "ORDE_N in(&sCtxRT0 ; /* resT/
 DsureosCtx.zlisi explain_d rc3333TE_OK Rrrcode(p->d
 rg;
  "notduchmoic E: *olumn_text(z);
      if()   rEstLoop =  constCble.
*{
ntf("EXPLAIN QUEaCREATg TABLte%s0 ){
    fite333while( *    1,'(g++;
    hexDigix *at(&sCtx rEstLoop = (tCble.
*{
ntf("EXPLAIN QUEa%z%clineFile); TEXT0 ){Cble.
, *   ,osCtx.z      /*   *    1,',f( z[i+1]>='0' sCtx.cTerm!=sCtx.cColSe  )  }
      sqlite3_stmt    c   ql'(grEstLoop = (szErr);
    frCble.
      /*   szErr);
    fsCtx.z      /*   xput fr(iCtx.inwritableSg ut, "ANAor: cano%s: emptywriti_columCtx.zt chwritableSpA  }
    zSelectuz[j] = (tCble.
*{
ntf("EXPLAIN QUEa%z\n)0 ){Cble.
writableS , 1,       tzQ2, dump_ca{Cble.
, 0RT0RTte3_crap (szErr);
    frCble.
      /*     fprintf(p->o>out, "ANAor: cannoCREATg TABLte%s(...Elfa ch zExp_colu{
        iCur, iHiwwriCmn_text(z);
      if()     /*   szErr);
    fsCtx.z      /*   xput fr(iCtx.inwritableSg   }
    zSelectuz[j] = (_prepare_v2(p->db, zTableInfo, -Smt, &zLeftover);0=SQLIstt = ap(p->db, b   frSintf(p->o    fprintf(p->o=' (  if(  (zErr);
 t);
      if( rc!=  g ut, "ANAor: canot open xp_column_text(z);
      if()     /* xput fr(iCtx.inwritableS  }
    zSelect = apnColzVamn_int(pExplain;
      if( rc!=  (zErr);
 t);
      if( rc!=  ;  pA 1, zQ2 =   retColqlite }
  if(0r */
nheExplai ,
nhee and  rc33opt ch {
ntf("EXPL );
  ifpnByt_*2 + 2- '0nCol*2 fite333      ch fprintf(stderr, "Error: cannot open derrttease inp->writableSxput fr(iCtx.inwritableS  }
    zSelect = apintf(len+100, zQ2nByt_+20, -Smt,  sqlite_ ... Filw); ", 0);
?0 ){
    fite3  jb= ery);
   rSintf(p->ouraySi1+){
 gol            airSin[j++ msg',f( z[i+1]rSin[j++ msg'?'zSelect = apzSin[j++ msg')'; = apzSin[j msg}PAretu_prepare_v2(p->db, zTableInfo, -Smt, &zLeftover);0=SQLIst(p->db, b   frSintf(p->o    fprintf(p->orr, "Error: cannot open xp_column_text(z);
      if()     /* =' (  if(  (zErr);
 t);
      if( rc!=  g xput fr(iCtx.inwritableS  }
    zSelect = apneedCto itrepare_v2(pgel_ utocto it    if(zQ2 =   reteedCto itr),       tzQ2, dump_ca)BEGIN"RT0RT0RTte3_crapdontf(p->o=ray(cartL FIb= sCtx.nL FIrc!=  g uol; i++){
 gol            ai 
  conste{
x *at(&sCtx ritableSg /*itableSg hexDid w
*reivedRDE-of-name beu[iewrind.  DenyeExplai ?itableSg hexIf so i(copo=rstrned furned namfrom ** f emFILrom Explai .itableSg h  }
            fprrrciqlite 
  }
  retueSg /*itableSg hexDid w
*reivedRDE-of-name ORdRDE-of- valubeu[iewrind.  DenyitableSg hexExplai  nt[ASCIIyport? xIf so i(copo=rstrned furned namfromitableSg hex** f emFILrom Explai .itableSg h  }
           nAport==of:\_Aer NNrrctz;
  ||Ct    i0)rrrciqlite 
  }
  retueSg (zErr);
FiDE_nfo, 1over);i+ luz,i-F8, 0,
   TRANSIENT ritableSg TE_Ci
 gol-1trrcoCtx.cTerm!=sCtx.cColSe  )      ai 
anrr, "Error: canno%s:%dopexpecRetu%dxExplai  bhe n
  tu%dx- "                          s"namfrom ** f estv' ){ rned       iCur, iHiwwriiiiiiiieSg (Ctx.zt chlu(cartL FI,y golaci+  if( !pData ) hile( (x         & z[i-1]<=nColz){ (zErr);
FiDE_RING(0over);isqf( s;urn iac cow++;
    r    /*     oCtx.cTerm==sCtx.cColSe  )      ai 
dontf(p->ooooox *at(&sCtx ritableSg  f( s;n iac cow+& z[i-1oCtx.cTerm==sCtx.cColSe  )ritableSg ut, "ANAor: canno%s:%dopexpecRetu%dxExplai  bhe n
  tu%dx- "                         "  tra  ngn[ier       iCur, iHiwtrSQiiiieSg (Ctx.zt chlu(cartL FI,y golaci     nRow++;
    TE_Ci>=nColz){ retueSg (zErr);

          ritableSg  prepare_v2(p(coet;
     ritableSg     fp!{
      sqlite3_crdeeSg ut, "ANAor: canno%s:%dopsqlite_fa ch zExp_colu(Ctx.zt chlu(cartL FI,   iCur, iHiwtrSQiimn_text(z);
      if()     /*   ++;
    r    /+& z[i-1oCtx.cTerm! EOF");aQ2 = xput fr(iCtx.inwritablszErr);
    fsCtx.z      /(zErr);
 t);
      if( rc!=    reteedCto itr),       tzQ2, dump_ca)COMMIT"RT0RT0RTte3_crLg[0]mp(zType    i ci]!(o "CREATzType = ns) nd.cin  0nzPre   iCur, iHiwtrSQitric "CREATzType = ns) ndles\  0nzPre)b){e3_stp){
  sqlit
  "zTmp = 0;
  rc =rr_msg}PA= aplState *p);0=SQLIitasecpyl&
  "
    *));of(
  "=     nR
  "     H off\ 1,0zSelec
  " port\= of:\_List     /  returnql1= z[++i];
ustep(p->db, zQ2, dump_cSelece3,ARRT INTO3_er_sequence;\n"name,t "         "WHERE"i);
=,table0 AND"VFS sNOTu TABL'sce;\n"%' "         "UN*** Aed "         "RT INTO3_er_sequence;\n"n"mp"name,t "         "WHERE"i);
=,table0 "         "id DESC",1"    iCur,  &zErr);
 &
  "
 &rc =rr_   iC  writabl rc =t  returnql2"isplay_sczp){
  sqlise{
zType 1 c=='a' )ustep(p->db, zQ2, dump_cSelece3,ARRT INTO3_er_sequence;\n"name,t "         "WHERE"i);
=,table0 AND"tbl_".
*/ TABLunc, 0, 0);() "         "UN*** Aed "         "RT INTO3_er_sequence;\n"n"mp"name,t "         "WHERE"i);
=,table0 AND"tbl_".
*/ TABLunc, 0, 0);() "         "id DESC",1"    iCur,  &zErr);
 &
  "
 &rc =rr_   iC  writabl  zp){
  sqlise{
}PAretu rc = SQLITE_rr, "Error: cannoUt.
*:   ndles\   TAB-PATTERN?orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = ap      fp   *pzErrMsg ut, "ANAor: canot open xp_coluree(rr_Err ){
  (zErr);
    free(rr_Err ){
   , 1, zSelectrc =t  re , != 
      sqlite3_crdeut, "ANAor: canot open lect,rom nce;\n"name,t ly tnce;\n"n"mp"name,torewritableS , 1, zSelect = rg[0]mpTE_MIT_LOAD_EXENABLt_IOTRACEp(zType    i ci]!c "CREATzType = ns) ock(v   0nzPreb){e3_stLOAD_EXAPIatitR   ce_ca(PT;
    DECLm*(zErr);IoTk(v ))sqlite3_col, ...E     /  re ock(v rrrciock(v !=sse ifte uf){
  iock(v E     / ock(v r   zQ2 =   return<2"isplay_sc(zErr);IoTk(v e{
}PAretu rc =zFile, "off"zType 1 ns)-")   rEstLoop =(zErr);IoTk(v e{
 ock(v P, "AN     /* =ock(v r  lse if( retu rc = SQLITE_=ock(v r  f"rb")zType 1 ns)w")     /* ='re ock(v    rEstLoop = (rr, "Error: cannot open \"%s\"\n", zFile);
    zSql = a   fpriy_sc(zErr);IoTk(v e{
}PAretubleS , 1, zSelece3+g[0]zErrMsg g szErr);IoTk(v e{
 ock(v P, "AN     /* }Select = rg[0]mqlite3_crType    l ci]!*>=5ci]!c "CREATzType = ns)separn  0nzPreb){e3_st4oleanV { char *zSuffErrMsg g Sql;
  constLepar *in;v* /zAult tefia separ h  }
     =rayseparCortr            /zArgoolean){
  t
  " a/
l par h  }
  } aLepar "KiB", 10200000whig){000               PT;
   LIENSILENGTH0               }
  },, 10200000szE_whig){000           PT;
   LIENSIPT;ILENGTH0               },, 10200000Explai000               PT;
   LIENSICOLUMN0               }
  },, 10200000expr_dep){000           PT;
   LIENSIEXPR_DEPTH0               },, 10200000Exmp
  t_selecR000      PT;
   LIENSICOMPOUND_RT INTO          },, 10200000vdbe_op000              PT;
   LIENSIVDB  sP               }
  },, 10200000func"wri_arg000         PT;
   LIENSIFUNC****_ARG          }
  },, 10200000attses\d000             PT;
   LIENSIATTACHED              }
  },, 10200000like_pattR  _whig){000  PT;
   LIENSILTAB_PATTERNILENGTH0      },, 10200000variON;\ntes wr000      PT;
   LIENSIVARIABLt_NUMBDES      }
  },, 10200000'riign _dep){000        PT;
   LIENSITRIGGER_DEPTH0            },, 10200000workn _th>aids000       PT;
   LIENSIWORKER_THREADS            },, 102}zQ2 =  lue c;n2PA= aplState *p);0=SQLIit  returnql1= z[++i];

raySize(aMult); i++){Lepar)            ai 
AIN QUEa%20s %r    0 Lepar zArgLepar *in p->zDbFileeeeeeee(zErr);
l par dump_ca Lepar zArseparCort,i-Fp     nRow++;
   rc =t  return>3= z[++i];
rr, "Error: cannoUt.
*:  l par  Exec?NEW-", 0)?orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelectrc = SQLITE_ zArgLepar 1,- zSelece3n2 Query);
   zType  a   fpriy_
raySize(aMult); i++){Lepar)            ai 
File,de(p->d
 rniREATzLepar zArgLepar *in pzType 1 nsn2)   rEstLoop = (* ='re Lepar< rEstLoop = (*  rgLepar 1,i;tLoop = (* +g[0]zErrMsg g i];
rr, "Error: cannoambiguous
l par:zFile);
    zSql = a   fpriy_scbleS , 1, zSelece3elece3go*/
meta_ to FIL_  itzSelec  nRow++;
  nRow++;
  nR++;
    TE_CiLepar< rEstLoop = (ut, "ANAor: cannoenknown;l par:zFile);
                           " g aszFi l pare); ' ){ no** is wririt
  a sest.       iCur, iHiwwriiiiiiiieSgzSql = a   fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    TE_Cturnql3z){ retueSg (zErr);
l par dump_ca Lepar zLeparArseparCort,   iCur, iHiwwriiiiiiiiz);
 izArg) & 0xffzSql =2]p     nRow++;
    AIN QUEa%20s %r    0 Lepar zLeparArgLepar *in    iCur, iHiww(zErr);
l par dump_ca Lepar zLeparArseparCort,i-Fp     nRt = rg[0]mpTE_OMIT_LOAD_EXTENSILOADIEXTENS***_crType    l ci]!c "CREATzType = ns)soad  0nzPreb){e3_st
Sql;
  constt chlu*zP(ShzTmp = 0;
  rc =rr_msg}PA= ap  return<2"isplay_scrr, "Error: cannoUt.
*:  loadplong ?ENTRYPO ..?orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = apzt char*zType 1 c=='a'zP(Shb= *azA>=3 ? zSql =2a : }PA= aplState *p);0=SQLIitustep(p->db, loadb)QtRD1);
leInfo, -t chluzP(Sh
 &rc =rr_Err ){
    fp!{
      sqlite3_crderr, "Error: cannot open xp_coluree(rr_Err ){
  (zErr);
    free(rr_Err ){
   , 1, zSelect = rg[0]mqlite3__crType    l ci]!c "CREATzType = ns)sog  0nzPreb){e3_st  return!l2"isplay_scrr, "Error: cannoUt.
*:  sog   ".restorewritableS , 1, zSelectg[0]zErrMsg 
Sql;
  constt che{
zType 1 c=='a' )close(FILE *f){
  u *pLo_Err ){
  u *pLo_e{
close(FILE *"rb");t chwritablt = rg[0]mp(zType    m ci]!c "CREATzType = ns)port  0nzPreb){e3_st
Sql;
  constMort\= *azA>=2 ? zSql = a : m"zQ2 =  luen2 Quz);
    whileMort)zQ2 =  luec2 QueMorts0];tLoopType 2   l ci]!*2>2ci]!c "CREATzType 1 n" vals00n2)   rEstLoop = 0;port\= of:\_L FIrc!=   rc =t  re 2   c'trrco "CREATzType 1 n"Explai 00n2)   rEstLoop = 0;port\= of:\_ delimzSelec rc =t  re 2   l ci]!*2>2ci]!c "CREATzType 1 n" vst00n2)   rEstLoop = 0;port\= of:\_L stzSelec rc =t  re 2   h ci]!o "CREATzType 1 n"html00n2)   rEstLoop = 0;port\= of:\_HtmlzSelec rc =t  re 2   t ci]!o "CREATzType 1 n"tcl00n2)   rEstLoop = 0;port\= of:\_Tclrr ){
  (zErr);
+100, zQ2*));of( nAcolS optiona=,, 0;colS optiona,)nTP_]) ) writabl rc =t  re 2   c'trrco "CREATzType 1 n"Esv00n2)   rEstLoop = 0;port\= of:\_ svrr ){
  (zErr);
+100, zQ2*));of( nAcolS optiona=,, 0;colS optiona,)nTP_Cto aErr ){
  (zErr);
+100, zQ2*));of( nAr     ptiona=ns 0;r     ptiona,)nTP_CrLf)zSelec rc =t  re 2   t ci]!o "CREATzType 1 n"tabs00n2)   rEstLoop = 0;port\= of:\_L strr ){
  (zErr);
+100, zQ2*));of( nAcolS optiona=,, 0;colS optiona,)nTP_Tab=SQLI   rc =t  re 2   i ci]!c "CREATzType 1 n"ig    00n2)   rEstLoop = 0;port\= of:\_tur   SQLIelecset_uery(p".
**p, nazA>=3 ? zSql =2a : "uery("=SQLI   rc =t  re 2   a ci]!c "CREATzType 1 n"ter N00n2)   rEstLoop = 0;port\= of:\_Aer Nrr ){
  (zErr);
+100, zQ2*));of( nAcolS optiona=,, 0;colS optiona,)nTP_Unif     nRnR(p->db, +100, zQ2*));of( nAr     ptiona=ns 0;r     ptiona,)nTP_Record=SQLI   rc =tte3_crdeut, "ANAor: canot open port\sheqt sbed    of: "          "ter Nlator anEsv html ig    w valumatchtabs tclorewritableS , 1, zSelect = rg[0]mp(zType    n ci]!c "CREATzType = ns)RING
){
   0nzPreb){e3_st  returnql2"isplay_sc(p->db, +100, zQ2*));of( nARING& 0xf=ns 0;RING& 0xf    iCur, iHiwwriiiiiiiie"%.*s000z);
 ult); i++) nARING& 0xf=-F8,zSql = a   fpri rc = SQLITE_rr, "Error: cannoUt.
*:  RING
){
  STRINGorewritableS , 1, zSelect = rg[0]mp(zType    o ci]!c "CREATzType = ns)"rb"  0nzPrebi]!*>=2"isplay_s            dDbar*eInfo;e3_st
Sql;
  constS   dt chn char*eInzDbt chn chzTmp = 0;
  rNewt chn char*}PA= apeInfomsg}PA= ap  return>=2"i rNewt chn char*ntf("EXPLAIN QUEa%s   zSql = a   fprieInzDbt chn ch QueNewt chn chPA= aplState *p);1Err ){
    eInfo!  rEstLoop =(zErr);*f){
      dDbErr ){
  (zErr);
    feInzF   Onput fErr ){
  u *zF   Onput f QueNewt chn chPA= ap rc = SQLITE_izErr);
    frNewt chn chErr ){
  u *fomsg    dDbrr ){
  u *zDbt chn ch QueS   dt chn chzSelect = rg[0]mp(zType    o Selei]!(o "CREATzType = ns)close(  0nzPrebtric "CREATzType = ns)onc   0nzPre)   qlite3_ Sql;
  constt che{
*azA>=2 ? zSql = a : mlse if"PA= ap  return>2"isplay_scrr, "Error: cannoUt.
*:  %s   ".
    zSql =0]writableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = ap  ret>1trrco "CREATzType = ns)onc   0nzPre"isplay_sc  return<2"isplay_scscrr, "Error: cannoUt.
*:  onc    ".
     fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    n", zIC
    le( (x    rc = SQLITE_n", zIC
    le*zTmp =t = apclose(F(coet; =SQLI      zt chzArg[1|sbispTE_MIT_LOAD_EXTENSIPOPE3_enab;
rr, "Error: canot open piplliareor stdupshel (S zetn"
 OSp->writableS , 1, zSelece3pnAclo }else if( #g[0]m3333SQpnAclo }ep"rb");t ch + 1ns)w")     /* ='repnAclo   rEstLoop = (rr, "Error: canot open \"%s\"\n", zpiplzFile);
    }
  } + 1   fpriy_scpnAclo }else if( fpriy_sc , 1, zSelece3+g[0]zErrMsg g szErr); +100, zQ2*));of( nAcloname=ns 0;clonamens);s0 ){t chwritableS}sqlite3_crea rc = SQLITE_pnAclo }eclose(FILE *"rb");t chwritabl* ='repnAclo   rEstLoop = (File, "off")t chl"off")!  rEstLoop = (* rr, "Error: canot open \"%s\"\wry da*/
File);
    }
  }
  retueSow++;
  nRowpnAclo }else if( fpriy_sc , 1, zSelece3+ rc =tte3_crdeg szErr); +100, zQ2*));of( nAcloname=ns 0;clonamens);s0 ){t chwritableS}sbleS}sblrg[0]mp(zType    p ci]!*>=3trrco "CREATzType = ns)00, z  0nzPreb){e3_st zArNrr ){
uraySi1+){
  ){
f          aiTE_Ci>1te ut, "%s;\n", zSql ")     /* ut, "%s\n", zIns);s0 )zType ( =SQLIstt = aput, "%s;\n", zSql   sqlitsg[0]mp(zType    p ci]!o "CREATzType = ns)00ompt  0nzPreb){e3_st  return >le() {   iCuro "CRpy(mFILP0ompt,zType 1 nz);
 ult); i++)mFILP0ompt=-F=SQLI  t = ap='+'nurn >le3) {   iCuro "CRpy(textinueP0ompt,zType 2 nz);
 ult); i++)textinueP0ompt=-F=SQLI  t = sg[0]mp(zType    q ci]!o "CREATzType = ns)quit  0nzPreb){e3_st_step2qlitsg[0]mp(zType    r ci]!*>=3trrco "CREATzType = ns)>aid  0nzPreb){e3_stlong *alt     /  return!l2"isplay_scrr, "Error: cannoUt.
*:  urned  ".
     fpriy_ , 1, zSelece3go*/
meta_ to FIL_  itzSelect = apaltr  f"rb")zType 1 ns)rbewritabl  realt fprintf(stderr, "Error: canot open \"%s\"\n", zFile);
    zSql = a   fpriy_ , 1, zSelectg[0]zErrMsg  , 1,t(Shell_
ot a*p, zl( rc!=  g uf){
  zl( rc!=  t = sg[0]mp(zType    r ci]!*>=3trrco "CREATzType = ns)>asonat  0nzPreb){e3_st
Sql;
  constSrct ch;tLoop Sql;
  constDb;play_s        pSrc;play_s      aFILE   *pefaultSQLI   zArnTimeclo }e0;aQ2 =   returnql2"isplay_sczprct che{
zType 1 c=='a' )tDbar*m FILf( sqde rc =t  returnql3"isplay_sczprct che{
zType 2 c=='a' )tDbar*zType 1 c=='a' rc = SQLITE_rr, "Error: cannoUt.
*:  >asonat ?DB?d  ".
     fpriy_ , 1, zSelece3go*/
meta_ to FIL_  itzSelect = ap_step(pTableI"rb");prct chLeftorc     nR    fp!{
      sqlite3_crderr, "Error: cannot open \"%s\"\n", zFile);
    }prct chErr ){
  (zErr);
f){
  uorc     nReS  }
    zSelect = aplState *p);0=SQLIite3ILE   =/lize(pTaFILE  );
   uInfo, -Db, uorc,*m FILfErr ){
    e3ILE   fprintf(stderr, "Error: cannot open xp_column_text(z);
      if()     /* (zErr);
f){
  uorc     nReS  }
    zSelect = ap& z[i-1t_step(pTableIFILE  )
     3ILE  ,240) ){
      sqtLoop = (* trifp=| nRow==BUSY "isplay_sc  refp=| nRow==BUSY EstLoop = (FilenTimeclo++ >le3te 
  }
  retueSg (zErr);
sle   240)ritableS}sbleS}sblee(zErr);
FILE  )f;
 sh  3ILE  =SQLI      fp=| nRow==DONE"isplay_scr, 1,      /rg[0]c  refp=| nRow==BUSY trifp=| nRow==LOCKEDrintf(stderr, "Error: cannot open sourcedls to opei  bhsyorewritableS , 1, zSelectg[0]zErrMsg rr, "Error: cannot open xp_column_text(z);
      if()     /* r, 1, zSelect = ap(p->db, f){
  uorc     sg[0]mpp(zType    s ci]!o "CREATzType = ns)s\"%4olen  0nzPreb){e3_st  returnql2"isplay_sc 0; \"%4olenOn =e(char *zArg){zSql = a   TE_OMIT_LOAD_EXENABLt_STMT_SCAN, (vUSErrMsg rr, "Error: cannoWarLrom:   \"%4olenigit.
vailic EX zetn"
 build.orewriqlite3_crea rc = SQLITE_rr, "Error: cannoUt.
*:   \"%4oleni     TorewritableS , 1, zSelect = rg[0]mp(zType    s ci]!o "CREATzType = ns)s\;
    0nzPreb){e3_stp){
  sqlit
  "zTmp = 0;
  rc =rr_msg}PA= aplState *p);0=SQLIitasecpyl&
  "
    *));of(
  "=     nR
  "     H off\ 1,0zSelec
  " port\= of:\_Semi    nR  returnql2"isplay_sc zArg[0]=tabluraySi0;*zType 1  ( cf    *zType 1  ( \= ToLower(zType 1  ( writabl* ='re, "off"zType 1 n"sce;\n"name,t"    rEstLoop = ( 0;
  new_argv 2 n  new_colv 2 c=='a' )apnew_argv ArzAroCREATg TABLtence;\n"name,t (
                         "  i);
 iext,
                         "  ".
*/iext,
                         "  ibl_".
*/iext,
                         "  froh    fizArg) ,
                         "  sg(_iext
                         ")"c=='a' )apnew_argv 1 msg}PAretuowapnew_colv ArzArosg("PAretuowapnew_colv 1 msg}PAretuowap &zErr);l&
  "
 1nsnew_argv,pnew_colv   fpriy_sc , 1,
      sqzSelece3+g[0] ='re, "off"zType 1 n"sce;\n"n"mp"name,t"    rEstLoop = ( 0;
  new_argv 2 n  new_colv 2 c=='a' )apnew_argv ArzAroCREATg TEMP TABLtence;\n"n"mp"name,t (
                         "  i);
 iext,
                         "  ".
*/iext,
                         "  ibl_".
*/iext,
                         "  froh    fizArg) ,
                         "  sg(_iext
                         ")"c=='a' )apnew_argv 1 msg}PAretuowapnew_colv ArzArosg("PAretuowapnew_colv 1 msg}PAretuowap &zErr);l&
  "
 1nsnew_argv,pnew_colv   fpriy_sc , 1,
      sqzSelece3+g[0]stLoop = (zp){
  sqlise{
zType 1 c=='a' ) )ustep(p->db, zQ2, dump_cSelece3,AleRRT INTOsg(_seque"           "  \nT INTOsg(_smt, i);
 i);
rmibl_".
*/ibl_".
*, VFS s".
*,  zQuerx"           "h))))sequence;\n"name,t UN*** Aed"           "h))nT INTOsg(, i);
rmibl_".
*,s".
*,  zQuersequence;\n"n"mp"name,t) "           "WHERE"lower(ibl_".
*)/ TABLunc, 0, 0);()"           "h)AND"i);
! 'meta' AND"sg(_NOTrned "           "id DESC", zQue00   iCur, r, &zErr);
 &
  "
 &rc =rr_=SQLIelec  zp){
  sqlise{
}PAretuow++;
  >rc =t  returnql1= z[++i];
ustep(p->db, zQ2, dump_cSelece3,AeRRT INTOsg(_seque"          "  \nT INTOsg(_smt, i);
 i);
rmibl_".
*/ibl_".
*, VFS s".
*,  zQuerx"          "h))))sequence;\n"name,t UN*** Aed"          "h))nT INTOsg(, i);
rmibl_".
*,s".
*,  zQuersequence;\n"n"mp"name,t) "          "WHERE"i);
! 'meta' AND"sg(_NOTrned AND"VFS sNOTu TABL'sce;\n"%' "          "id DESC", zQue00   iCur, r &zErr);
 &
  "
 &rc =rr_   iC  writabl rc = SQLITE_rr, "Error: cannoUt.
*:   \    a  TAB-PATTERN?orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = ap      fp   *pzErrMsg ut, "ANAor: canot open xp_coluree(rr_Err ){
  (zErr);
    free(rr_Err ){
   , 1, zSelectrc =t  re , != 
      sqlite3_crdeut, "ANAor: canot open lect,rom n\    a    t thionorewritableS , 1, zSelectg[0]zErrMsg r, 1,      /r   sg[0]mppTE_yin\ined(PT;
   DEBUG)0 ){d.\ined(PT;
   ENABLt_ST INTTRACE)p(zType    s ci]!nql11trrco "CREATzType = ns)selecRck(v   0nzPreb){e3_sttitR   =ray(zErr);SelecRTk(v ;play_s      SelecRTk(v  1,izArg) & 0xffzSql = a     sg[0]mqlite3__pTE_MIT_LOAD_EXDEBUG
  /zAUndocs wri an to FILrit
  izArrnalttestrom.))nubjecRabasflue o
  hexwithclo gitice.  rc33) re    s ci]!*>=10trrco "CREATzType = ns)selftest-  09zPreb){e3_st  reo "CREATzType = +9ns)Fchar *  0n-9zPre"isplay_sc lue c;vrr ){
  uraySi1+){
  ){
f          aiTyv =e(char *zArg){zSql =ia   fpriy_scut, "%s\n", zIns);s:u%dx0x%x
    zSql =i nsv,pv)ritableS}sbleS}sblee  reo "CREATzType = +9ns)izArg)   0n-9zPre"isplay_sc lue ; (zErr);
 lu64;vrr ){
  uraySi1+){
  ){
f          aiTy 0;
 zBuf[200 c=='a' ) )v 1,izArg) & 0xffzSql =ia   fpriy_sc(zErr); +100, zQ2*));of(zBuf),zBufno%s: %lldx0x%llx
    zSql =i nv,v   fpriy_scut, "%s\n", zIns);solurBuf)ritableS}sbleS}sblrg[0]mqlite3__crType    s ci]!o "CREATzType = ns)s  ptiona  0nzPreb){e3_st  return<2 triturn>3= z[++i];
rr, "Error: cannoUt.
*:  d optionalCOL ?ROW?orewritableS , 1, zSelect = ap='+'nurn>l2"isplay_sc(p->db, +100, zQ2*));of( nAcolS optiona=,, 0;colS optiona,                       e"%.*s000z);
 ult); i++) nAcolS optiona=-F8,zSql = a   fpri  = ap='+'nurn>l3"isplay_sc(p->db, +100, zQ2*));of( nAr     ptiona=ns 0;r     ptiona,                       e"%.*s000z);
 ult); i++) nAr     ptiona=-F8,zSql =2]   fpri 
lecg[0]mp(zType    s  fpri]!(o "CREATzType = ns)unc,   0nzPrebtric "CREATzType = n"syme,m",nzPre)   qlite3_  constCmdSQLI   zAr c;x;e3_st  return<2  z[++i];
rr, "Error: cannoUt.
*:  dyme,msCOMMANDorewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = apzCmdar*ntf("EXPLAIN QUE, "ohr(zType 1 ,' 'zPre?);so:"File);   zSql = a   fpriuraySi2+){
  ){
f          aizCmdar*ntf("EXPLAIN QUE, "ohr(zType i ,' 'zPre?);z ;so:";z File);                         e    aizCmd )zType ( =SQLIstt = apxar*nyme,m(zCmdwritablszErr);
    fzCmdwritabl  rexte ut, "%s;or: cannoSyme,ms to FILE  }
  s %r    0xsqlitsg[0]mp(zType    s ci]!o "CREATzType = ns)show  0nzPreb){e3_st zArNrr ){
  return!l1= z[++i];
rr, "Error: cannoUt.
*:  showorewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = aput, "%s\n", zIn"%12.12sn xp_col)ff\n  0p0;ff\nOn ?s)one : moff"); = aput, "%s\n", zIn"%12.12sn xp_col)fqp  0p0;PLAIEQP ?s)one : moff"); = aput, "%s\n", zIn"%9.9sn xp_col)fff?     0 0;
ut tlM{
 .valid ?s)one :moff"); = aput, "%s\n", zIn"%12.12sn xp_col)ff    n  0 0;    H off\ ?s)one : moff"); = aput, "%s\n", zIn"%12.12sn xp_col)port  0portDescr[ 0;port]); = aput, "%s\n", zIn"%12.12sn "ns)RING
){
  writableSclose(Fc_,"no srn", zIns 0;
ING& 0xf=;[++i];
rr, "Err\n", zSql   sqlitaput, "%s\n", zIn"%12.12sn xp_col)close(               ery);
    nAcloname= ?s nAcloname : mlse if"); = aput, "%s\n", zIn"%12.12sn "ns)cols  ptiona writableSclose(Fc_,"no srn", zIns 0;colS optiona=SQLI  ;
rr, "Err\n", zSql   sqlitaput, "%s\n", zIn"%12.12sn "ns)r  s  ptiona writableSclose(Fc_,"no srn", zIns 0;r     ptiona=SQLI  ;
rr, "Err\n", zSql   sqlitaput, "%s\n", zIn"%12.12sn xp_col)4olen  0 0; olenOn ?s)one : moff"); = aput, "%s\n", zIn"%12.12sn ol)"    "   fpriura ySi0;i<z);
 ult); i++) nAcolWcolup";'  nAcolWcoluzi] != 0;i   *z[++i];
rr, "Errn", zIn"%d ol nAcolWcoluzi]=SQLIstt = aput, "%s;\n", zSl   sqlitsg[0]mp(zType    s ci]!o "CREATzType = ns)solen  0nzPreb){e3_st  returnql2"isplay_sc 0; olenOn =e(char *zArg){zSql = a   LIsttrc = SQLITE_rr, "Error: cannoUt.
*:   oleni     TorewritableS , 1, zSelect = rg[0]mp(zType    t ci]!*>1trrco "CREATzType = ns)S mill  0nzPreb){e3_st4e_funct= NULL;  pArg->    cons*azResult     / zArnRow, na);
 zTmp = 0;
  r ch {
}PA= aplbac Nrr ){
lState *p);0=SQLIitustep(p->db, ->db, zTableInfo, able_sch
  ".dbi_matc", &zLeftover);0=SQLIst    fpriS  }
   rc;play_t ch {
ntf("EXPLAIN QUE         RRT INTO3_er_sequence;\n"name,t"         " WHERE"i);
 IN (,'%q',0,,view0)"         "h))AND"VFS sNOTu TABL'sce;\n"%%'"         "h))AND"VFS s TABL?1ewritabl& z[i-1ode(p->d
           ){
        rEstLoop = Sql;
  constDbN ch Qu)sqlite3_col)mn_int(pExplainnfo, 1over);1   fpriy_     DbN chPrebtric "off")DbN ch,m FILfEqlite textinueritabl* ='re, "off")DbN ch,mn"mp"    rEstLoop = (t ch {
ntf("EXPLAIN QUE                  ";z UN*** Aed "                  "ST INTO'n"mp.' trit_er_sequence;\n"n"mp"name,t"                  " WHERE"i);
 IN (,'%q',0,,view0)"                  " ))AND"VFS sNOTu TABL'sce;\n"%%'"                  " ))AND"VFS s TABL?1e, -Smt)ritableS}g[0]stLoop = (zpch {
ntf("EXPLAIN QUE                  ";z UN*** Aed "                  "ST INTO'%q.' trit_er_sequeFilw);.nce;\n"name,t"                  " WHERE"i);
 IN (,'%q',0,,view0)"                  " ))AND"VFS sNOTu TABL'sce;\n"%%'"                  " ))AND"VFS s TABL?1e, -Smt,  DbN ch,  DbN ch)ritableS}sbleS}sblee(zErr);
 t);
      if( rc!=  t ch {
ntf("EXPLAIN QUEa;z id DESC",1"  rSintf(p->o_prepare_v2(p->db, zTableInfo, -Smt, &zLeftover);0=SQLIst(p->db, b   frSintf(p->o    fpriS  }
   rc;play_nRowe{
*a);
  {
}PA= apazResultmsg}PA= ap  return>1"isplay_sc(p->db, FiDE_nfo, 1over);1 pzType 1 ns-F8, 0,
   TRANSIENT ritabl rc = SQLITE_izErr);
FiDE_nfo, 1over);1 p"%"ns-F8, 0,
   , (vIC=SQLIstt = ap& z[i-1ode(p->d
           ){
        rEstLoop =  retRow>=*a);
  EstLoop = ( 0;
  *azNew  fpriy_sc luen2 Qu*a);
 *2 + 1}PAretuowapazNew epare_v2(p(c );
  ifazResult  *));of(azResult=0]w*n2   fpriy_sc  reazNew   rEstLoop = (* rr, "Error: cannot open derrttease inp->writableSSSSS
  }
  retueSg ++;
  nRow*a);
  {
n2PAretuowapazResultmsgazNew  fpriy_++;
  nRazResult=tRow]ar*ntf("EXPLAIN QUEa%s   mn_int(pExplainnfo, 1over);0)   fpriy_    azResult=tRow]a)etRow s;n iac}sblee(zErr);
 t);
      if( rretuowapA= ap  retRow>e"isplay_sc lue);
 0pax);
e{
}PAretuowilue c;
 AretuowiluenP, "AgolacnP, "ARowrr ){
  uraySi++){
 Rowrf          aiTy);
e{
ery);
   zTResult=ia   fpriy_sc  re);
>pax);
e)0pax);
e{
);
  fpriy_++;
  nRnP, "Agole{
80/(pax);
+2   fpriy_    nP, "Agol<1te nP, "Agole{
 zSelece3nP, "ARow Qu)nRowe+ nP, "Agole-;1 /nP, "Agolrr ){
  uraySi++){
 P, "ARowrf          aiTyurayj=i; j
 Rowrfj+= P, "ARowEstLoop = (*  0;
  r   =/j
 P, "ARow ?s)e : m  ";tLoop = (* rr, "Errn", zIns);s%-*s000r   0pax);
, azResult=j] ? zSResult=j]:">writableSSS++;
  nRowrr, "Err\n", zSql   sqlitapeS}sbleS}sbleeuraySSi++){{
 Rowrf i   *(p->db, b   fzTResult=iia   fpri(p->db, b   fzTResultsqlitsg[0]mp(zType    t ci]!*>=8trrco "CREATzType = ns)Sestcry)  0nzPrebi]!*urn>l2"isplay_4oleanV { char *zSuffErrMsg g Sql;
  constCry) *in;v* /zAult tefia test-textroleop"writh  }
     =raycry)Cortr            /zArgoolean){
  t
  " a/
op"writh  }
  } aCry) "KiB", 10200000prng_    000             0,
   TESTCTRL_PRNG_SAVE0             },, 10200000prng_>asonat  0          0,
   TESTCTRL_PRNG_RESTORE           },, 10200000prng_>aset"00           PT;
   TESTCTRL_PRNG_RESETO            },, 10200000bitvec_test"00          PT;
   TESTCTRL_BITVEC TEST            },, 10200000\") f_=rsta,   0        PT;
   TESTCTRL_FAULT_IN, (ed          },, 10200000benignPL );
 _hooks000  PT;
   TESTCTRL_BENIGN_M(edOC_HOOKS    },, 10200000pend.  _n is  0          0,
   TESTCTRL_PENDING_BYTE           },, 10200000as    00                 0,
   TESTCTRL_ASlite_________________},, 10200000always00                 0,
   TESTCTRL_ALWAYS                _},, 10200000>aser  000               0,
   TESTCTRL_RESERVE0              _},, 10200000op"wmizthions  0        PT;
   TESTCTRL_OPTIMIZA****S         _},, 10200000iskeyword000            PT;
   TESTCTRL_ISKEYWid              _},, 10200000scratchL );
   0        PT;
   TESTCTRL_SCRATCHM(edOC         _},, 10200000n isordwr000            PT;
   TESTCTRL_BYTEid DES            _},, 10200000nppeapExsrupt  0        PT;
   TESTCTRL_NEVER_CORRUPT         _},, 10200000 .shme,t"00             PT;
   TESTCTRL_IMPOSTDES            _ },, 102}zQ2 =  lueSestcry) 1,- zSelec luerc2 Qu}PA= aplbac c;n2PA= aplState *p);0=SQA= ap/ex.tiv   wSestcry) t,
  op"writto 
){
 ..
);
wDenyeuniquept(pfixA= ap**tefi** fop"writ".
*, 
  a numerical 
){
 ..h  }
  n2 Query);
   zType  a   fpri
raySize(aMult); i++){Cry))
f          aiTE_Cc "CREATzType 1 n aCry) zArgCry) *innsn2)   rEstLoop = (TE_CSestcry)< rEstLoop = (* Sestcry) 1,aCry) zArcry)CortritableSSS+g[0]zErrMsg g i]rr, "Error: cannoambiguous
op"writ".
*:zFile);
    zSql = a   fpriy_scblSestcry) 1,- zSeleccccccc
  }
  retueSg ++;
  nR}sbleS}sblee  reSestcry)< rElSestcry) 1,z);
 izArg) & 0xffzSql = a   fpri  re(Sestcry)<PT;
   TESTCTRL_FIRST) tri(Sestcry)>PT;
   TESTCTRL_LAST) ite3_crdeut, "ANAor: canot open invalid Sestcry) op"wrin xp_coluzSql = a   LIsttrc = SQLITE_switch(Sestcry)ite retueSg /ex(p->db, Sest_textrolz);
, fo, );
  h  }
      c opePT;
   TESTCTRL_OPTIMIZA****S: }
      c opePT;
   TESTCTRL_RESERVE:           _ SelecccccccTE_Cturnql3z){ retueSg ccccTn  op" Quz);
    tolzzType 2 nT0RTte3      _ Seleccccccc erc2 Qu(p->db, Sest_textrolzSestcry), eInfo, op"   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+ rc =tte3_crdeg crdeut, "ANAor: canot open Sestcry) %
 oikllia *)ng EX z  op"wri       iCur, iHiwwriiiiiizSql = a   fpriy_scbl}Seleccccccc
  }
   retueSg /ex(p->db, Sest_textrolz);
  h  }
      c opePT;
   TESTCTRL_PRNG_SAVE: }
      c opePT;
   TESTCTRL_PRNG_RESTORE: }
      c opePT;
   TESTCTRL_PRNG_RESET: }
      c opePT;
   TESTCTRL_BYTEid DE:SelecccccccTE_Cturnql2z){ retueSg ccccrc2 Qu(p->db, Sest_textrolzSestcry)   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+ rc =tte3_crdeg crdeut, "ANAor: canot open Sestcry) %
 oikllino op"wrip_coluzSql = a   LIsty_scbl}Seleccccccc
  }
   retueSg /ex(p->db, Sest_textrolz);
, u);
  h  }
      c opePT;
   TESTCTRL_PENDING_BYTE:        SelecccccccTE_Cturnql3z){ retueSg ccccunsign (S z  op" Quzunsign (S z  izArg) & 0xffzSql =2]p;Seleccccccc erc2 Qu(p->db, Sest_textrolzSestcry), op"   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+ rc =tte3_crdeg crdeut, "ANAor: canot open Sestcry) %
 oikllia *)ng EXunsign ("                          s m  z  op"wri    uzSql = a   LIsty_scbl}Seleccccccc
  }
  eleccccccc retueSg /ex(p->db, Sest_textrolz);
, );
  h  }
      c opePT;
   TESTCTRL_ASlite:           _   }
      c opePT;
   TESTCTRL_ALWAYS:   _   }
      c opePT;
   TESTCTRL_NEVER_CORRUPT:        SelecccccccTE_Cturnql3z){ retueSg cccc z  op" Qu(char *zArg){zSql =2]p;        Seleccccccc erc2 Qu(p->db, Sest_textrolzSestcry), op"   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+ rc =tte3_crdeg crdeut, "ANAor: canot open Sestcry) %
 oikllia *)ng EX z  op"wri       iCur, iHiwwriiiiiiiiiiiiiizSql = a   LIsty_scbl}Seleccccccc
  }
   retueSg /ex(p->db, Sest_textrolz);
,   cons  h  TE_MIT_LOAD_EXN_KEYWid  }
      c opePT;
   TESTCTRL_ISKEYWid :           SelecccccccTE_Cturnql3z){ retueSg cccc Sql;
  consop" QuzType 2 c        Seleccccccc erc2 Qu(p->db, Sest_textrolzSestcry), op"   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+ rc =tte3_crdeg crdeut, "ANAor: canot open Sestcry) %
 oikllia *)ng EX  cons op"wri       iCur, iHiwwriiiiiiiiiiiiiizSql = a   LIsty_scbl}Seleccccccc
  }
  qlite3__cr      c opePT;
   TESTCTRL_IMPOSTDE:SelecccccccTE_Cturnql5z){ retueSg ccccrc2 Qu(p->db, Sest_textrolzSestcry), eInfo,    iCur, iHiwwriiiiiiiiiiiizType 2 n   iCur, iHiwwriiiiiiiiiiiiizArg) & 0xffzSql =3])n   iCur, iHiwwriiiiiiiiiiiiizArg) & 0xffzSql =4])   fpriy_scbl* rr, "Errn", zIns);d (0x%08x)_colurc2lurc2   fpriy_scbl+g[0]zErrMsg g i];
rr, "Error: canoUt.
*:  Sestcry)  .shme,t foult tenoffi*nump->writableSSSSS}Seleccccccc
  }
   retueSg c opePT;
   TESTCTRL_BITVEC TEST:          retueSg c opePT;
   TESTCTRL_FAULT_IN, (ed:        retueSg c opePT;
   TESTCTRL_BENIGN_M(edOC_HOOKS:  retueSg c opePT;
   TESTCTRL_SCRATCHM(edOC:        retueSg in\") f:Selecccccccut, "ANAor: canot open CLItdupshel t
  "estcry) %
 git. .sle wri a       iCur, iHiwwriiiizSql = a   LIsty_scbl }
      sqlite3_stt = rg[0]mp(zType    t ci]!*>4trrco "CREATzType = ns)Simeclo  0nzPreb){e3_stlState *p);0=SQLIitizErr);
Fusy_SimecloleInfo, *azA>=2 ? z);
 izArg) & 0xffzSql = a  : }sqlitsg[0]m     reType    t ci]!*>=5ci]!c "CREATzType = ns)Simea  0nzPreb){e3_st  returnql2z){ retueSen%q',Timer =e(char *zArg){zSql = a   LIstst  reen%q',Timer i]!!HAS_TIMERrEstLoop = (rr, "Error: cannot open Simeaigit.
vailic EXozetn"
 nyme,m.p->writableSSSen%q',Timer =e}PAretuow++;
  >rc = SQLITE_rr, "Error: cannoUt.
*:  Simeai     TorewritableS , 1, zSelect = rg[0]m   reType    t ci]!c "CREATzType = ns)Sk(v   0nzPreb){e3_stlState *p);0=SQLIit  return!l2"isplay_scrr, "Error: cannoUt.
*:  ck(v r  ".   TorewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = apclose(FILE *f){
  u *ck(v Ou( rc!=  ; *ck(v Ou( }eclose(FILE *"rb")zSql = a   TE_ !d.\ined(PT;
   OENSITRACE) i]!!d.\ined(PT;
   OENSIFLOA**NG_PO ..)QLIit  re; *ck(v Ou(   rEstLoop =(zErr);_ck(v leInfo, 0RTte3_crap rc = SQLITE_izErr);
ck(v leInfo, szE_ck(v _ &zErr);
 u *ck(v Ou( rc!=  }sqlite3_crrg[0]mpTE_ePT;
   Ulit_AUTHENTICA**** reType    u ci]!c "CREATzType = ns)usea  0nzPreb){e3_st  return<2  z[++i];
rr, "Error: cannoUt.
*:  usea SUBCOMMAND ...orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelect = apcState *p);0=SQLIit  re, "off"zType 1 n"logILfEqlitestLoop =  return!l4"isplay_scscrr, "Error: cannoUt.
*:  usea logIL Ulit PASlWid 
     fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    _prepare_v2(pusea_ uthwriilain dump_ca Type 2 nTzSql =3]                        e    aiiiiiiiiz);
    whilzSql =3])   LIstst  refprintf(p->o>out, "ANAor: cannoAuthwriilaiwritfa ch  t
  usea xp_coluzSql =2]p;Seleccccc , 1, zSelece3+_crap rc =t  re, "off"zType 1 n"addfEqlitestLoop =  return!l5"isplay_scscrr, "Error: cannoUt.
*:  usea add Ulit PASlWid  ISADMIN
     fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    _prepare_v2(pusea_ dd dump_ca Type 2 n   iCur, iHiwwriiiiiiiiiiiiiizSql =3] iz);
    whilzSql =3])n   iCur, iHiwwriiiiiiiiiiiiii(char *zArg){zSql =4])   LIstst  refprintf(p->o>out, "ANAor: cannoUsea-Add fa ch zExd_colurcp;Seleccccc , 1, zSelece3+_crap rc =t  re, "off"zType 1 n"editfEqlitestLoop =  return!l5"isplay_scscrr, "Error: cannoUt.
*:  usea edit Ulit PASlWid  ISADMIN
     fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    _prepare_v2(pusea_flue o dump_ca Type 2 n   iCur, iHiwwriiiiiiiiiiiiiiiizSql =3] iz);
    whilzSql =3])n   iCur, iHiwwriiiiiiiiiiiiiiii(char *zArg){zSql =4])   LIstst  refprintf(p->o>out, "ANAor: cannoUsea-Edit fa ch zExd_colurcp;Seleccccc , 1, zSelece3+_crap rc =t  re, "off"zType 1 n"deletefEqlitestLoop =  return!l3"isplay_scscrr, "Error: cannoUt.
*:  usea delete Ulit
     fpriy_sc , 1, zSelece3elgo*/
meta_ to FIL_  itzSelec  ++;
    _prepare_v2(pusea_delete dump_ca Type 2    LIstst  refprintf(p->o>out, "ANAor: cannoUsea-Delete fa ch zExd_colurcp;Seleccccc , 1, zSelece3+_crap rc =z[++i];
rr, "Error: cannoUt.
*:  usea logIL| dd|edit|delete ...orewritableS , 1, zSelece3go*/
meta_ to FIL_  itzSelectelec_crrg[0]mqlite3 /exPT;
   Ulit_AUTHENTICA**** h   reType    v ci]!c "CREATzType = ns)ver1);
  0nzPreb){e3_strr, "Errn", zIns)PT;y da%
 xp_co /e  tra-ver1);
-    */n   iCur, (zErr);
l bver1);
()  mn_int(psourceid()sqlitsg[0]mp(zType    v ci]!c "CREATzType = ns)vfs".
*  0nzPreb){e3_st
Sql;
  constDbN ch Quturnql2z? zSql = a : m FILf( sqde  constVfsN char*}PA= ap    eInforEstLoop =(zErr);_ILE *fextrolzuInfo, -Db *innsPT;
   FCNTL_VFSrest
 &rVfsN ch   fpriy_     VfsN chaintf(p->o>out, "ANAn", zIns);s_colurVfsN ch   fpriy_st(p->db, b   frVfsN ch   fpriy_te3_stt = rg[0]mpTE_yin\ined(PT;
   DEBUG)0 ){d.\ined(PT;
   ENABLt_WHERETRACE)p(zType    w ci]!c "CREATzType = ns)whereck(v   0nzPreb){e3_sttitR   =ray(zErr);WhereTk(v ;play_s      WhereTk(v e{
*azA>=2 ? (char *zArg){zSql = a  : }xff;_crrg[0]mqlite3
p(zType    w ci]!c "CREATzType = ns)w    " 0nzPreb){e3_st zAr
 Aretuas    return<=ult); i++){Type) writablurayj=1; j
 ypeci]!j<ult); i++) nAcolWcoluprfj+        ai nAcolWcoluzj-1 msgz);
 izArg) & 0xffzSql =j]   fpri 
lecg[0]mp(z{e3_strr, "Error: cannot open enknown; to FILE
  izvalid a is wrir: "       "zFile);. Eg aszFi help\" t
  help\    zSql =0]writabl , 1, zSel}

meta_ to FIL_  it:
* ='repnAcloC
           pnAcloC
   --PA= ap    eIncloC
   qlite close(F(coet; =SQLI 
le  }
   rc;p}

/*
** R }
   TRUEp  ia *emicolritoccursDenywhereX zetnewrirl;
Ne  coac ass
**tefi,"no s z[].
h  4oleanV lue)ine*fextFILs_*emicolri(
Sql;
  const, );
 N      zArNrr )
raySize(aMN
f     y_     [irg[1;'riS  }
   1;I 
le  }
   0;p}

/*
** Testv*/
seep  ia  valu
Sqlists wriirelytefiwh   s) ) .
h  4oleanV lue_&zE_wh   s) ) (
Sql;
  const     
ray;nst; z+            Is]) ) (t   )te textinueritabl    *zg[1/ ci]!z= ag[1*'"isplay_sczhile( (x     & z[i-1*zri]!(*z![1*'"||Ct 1]![1/ ) it z+ ;urn iac c    *zg[0riS  }
   }PAretuowz s;n iac ctextinueritabl}itabl    *zg[1- ci]!z= ag[1-'"isplay_sczhile( (x     & z[i-1*zri]!*z![1\n' it z+ ;urn iac c    *zg[0riS  }
   1;n iac ctextinueritabl}itabl  }
   }PAre 
le  }
   1;p}

/*
** R }
   TRUEp  itnew valui);
(S zeisDensPT;; to FILE asminionalotner
** tlueia *emi-colri.  ThpePT; Ser  ri,"yle "go"; to FILEisDun   ntood
** a  nsitnewOoacle "/".
h  4oleanV lue)ine*is_ to FIL_ asminiona(
Sql;
  constL FIispla& z[i-1Is]) ) (tL FI   )tet zL FI+ ;ur;
* ='retL FI   g[1/ ci]!_&zE_wh   s) ) (&tL FI 1]) ite3_cr  }
   1;I /exOoacle h  }
}
* ='reToLower(tL FI   )g[1g ci]!ToLower(tL FI 1 )g[1o Seleeeeeeei]!_&zE_wh   s) ) (&tL FI 2]) ite3_cr  }
   1;I /exPT; Ser  rih  }
}
*   }
   0;p}

/*
** R }
   truep  it ch isDe; toplete PT; 4olee wri.  R }
   fac =t   it
** eILri zetnewmiddl tefia ,"no s     ralE
  C-,"yle  to wri.
h  4oleanV lue)ine*is_ toplete( 0;
  r ch, );
 nSint     zArrc;pla='retSing[0riS  }
   1;n itSin[nSin msg1;';n itSin[nSin+1 msg}PAre_prepare_v2(p toplete(rSintf(p-tSin[nSin msg}PAre_ }
   rc;p}

/*
** R a(S zse( from * zeFILEt(Shell it.  If * zg[0rthwrS zse(
** is izArrac ive -etnewusea nsitypo s it it.  Otnerwise,S zse(
** is  too s from a name oa device.  A 00ompt is issu
(SFILEhisonay
** is     d onlyt   izse( is izArrac ive.  An izArrrupt signalEwill
** causeetn"
 rclovaluio   it io wdileely,Dunlell izse( is izArrac ive.
**
** R }
   tnewtes wrtefie opes.
h  4oleanV luet(Shell_
ot a*p){
  sqlit*p,tlong *int      constL FImsg}Peleeeeeee /exA *)ng EX zse(  valuh  }
 0;
  r ch {
}P eleeeeeee /exAccumulai anPT; t,
   rc33);
 nL FIr                /exLhig){teficurren(  valuh  }
);
 nSin {
}P eleeeeeee   /exBy  stefitSin[]wuseduh  }
);
 na);
  {
}P eleeeeeee /exA);
 ai antSin[]ws) ) uh  }
);
 nSinPrior {
}P eleeeee/exBy  stefitSin[]wuseduby AINor  valuh  }
 0;
  ree(rr_r            /zAt ope
mest.
*e_ }
  eduh  }
);
 rc;                   /zAt ope
){
  h  }
);
 e oC   le*z           /zANes wrtefie opes
seen h  }
);
  valno le*z           /zACurren(  valutes wrth  }
);
 4olrtl FImsg}Peleeeeee/exLvalutes wrtt
  4olrtteficurren(  zse( h   re& z[i-1e oC  Prebtri!bail_on_e ope tri( zg[0ri]!c din*is_izArrac ive) ite3_crfflush  Inclo rc!=  tL FImsgone*izse(_l FI( z, tL FI, nSin>0=SQLIit  retL FIqlitestLoop =/zAtILE
f  zse( h  Loop =  re, din*is_izArrac iveriSAIN QUEaorewritableS }
      sq}sblee  reoeenIzArrrupt        aiTE_Cin!  rEl }
      sqlioeenIzArrrupt le*zTmp =t = ap valno s;n iac  retSing[0ri]!_&zE_wh   s) ) (tL FIi        aiTE_Cp0;ff\nOn iSAIN QUEa;s_colurL FIi;n iac ctextinueritabl}itabl    tL FImi]!zL FI   g[1. ci]!*Sing[0ri      aiTE_Cp0;ff\nOn iSAIN QUEa;s_colurL FIi;n iac c_prepdo_meta_ to FIL(tL FI, p   LIstst  refpql2z){=/zA  it requesteduh  }
tableS }
      sqectrc =t  re , intf(p->o>oe oC   s;n iac c}n iac ctextinueritabl}itabl    )ine*is_ to FIL_ asminiona(tL FIi i]!)ine*is_ toplete(r ch, nSint intf(p->oasecpyltL FI,";",2)ritabl}itablnL FImsgery);
   rL FIi;n iac  retSin+nL FI+2>=*a);
  EstLoop =*a);
  {
nSin+nL FI+10}PAretuowzSin {
(c );
 (r ch, na);
    fpriy_     Sing[0ri      ai* rr, "Error: cannot open derrttease inp->writableSSS  it(1   fpriy_te3_stt =   nSinPrior {
nSin;n iac  retSing[0risplay_sc zArg[0]=tabluraySi0;*zL FI i] i]!Is]) ) (tL FI ia  f     ++;
  nRas    retu);
 >0ri]! Sin!  rE;tf(p->oasecpyltSmt,  L FI+ c;nL FI+1-iE;tf(p->o4olrtl FImsg valno;tf(p->onSin {
nL FI-g[0]=ta rc =z[++i];
tSin[nSin++ msg1\n';tf(p->oasecpyltSmt+nSmt,  L FIc;nL FI+1);tf(p->onSin +{
nL FIritabl}itabl    nSin i]!)ine*fextFILs_*emicolri(&tSin[nSinPrior], nSin-nSinPrior)Seleeeeeeeeeeeeeei]!cre_v2(p toplete(rSint"isplay_sc 0;c   le*zTmp =apcState *p);0=SQLIitaiTE_Cp0;rr);slashOn iSresolve_rr);slashes(-Smt)ritableSBEGIN_TIMER;n iac c_prepunc,  zQ2, dump_c -Smt, unc,   &zErr);
 u
 &rc =rr_=SQLIelecEND_TIMER;n iac c  re , ||Ct fp   *pzErrMsg Ty 0;
 zP(pfix[100 c=='a' ) )TE_Cin!  rtri!, din*is_izArrac iveri{Seleeeeeeee(zErr); +100, zQ2*));of(zP(pfix), zP(pfix,    iCur, iHiwwriiiiiiiiiiiinot open near  valu%d:   molrtl FIwritableSSS+g[0]zErrMsg g i](zErr); +100, zQ2*));of(zP(pfix), zP(pfix, ot open>writableSSS++;
  nRow      fp   !  rEstLoop = (* rr, "Error: cans);s xp_colurP(pfix, rc =rr_=SQLIelec    (zErr);
    free(rr_Err ){
      rc =rr_msg}PA= apeSSS+g[0]zErrMsg g i]rr, "Error: cans);s xp_colurP(pfix, (zErr);
z);
      if()     /* SS++;
  nRowe oC   s;n iac c}n iac cnSin {
}PQLIitaiTE_Cp0;cloC
               close(F(coet; =SQLI      n", zIC
    le*zTmp =e3+_crap rc =t  renSin i]!_&zE_wh   s) ) (tSint"isplay_scTE_Cp0;ff\nOn iSAIN QUEa;s_colurSmt)ritableSnSin {
}PQLIit} }
}
* ='renSin            !_&zE_wh   s) ) (tSint"isplay_scrr, "Error: cannot open in toplete PT;n xp_colurSmt)ritableSe oC   s;n iac}sbleeu   frSintf(p-}sblu   frL FIi;n i_ }
   e oC  >0;p}

/*
** R }
   a pathVFS swh ch nsitnewusea's hoS sdireconay.  A
** 0i_ }
   indilainsDense ope efi,oS skind.
h  4oleanV 0;
  fiDE_hoS _dir(voidispla4oleanV 0;
  hoS _dir {
rned;pla='rehoS _dir iS  }
   hoS _dir;
 TE_ !d.\ined(_WIN32) i]!!d.\ined(WIN32) i]!!d.\ined(_WIN32_WCE) \itablei]!!d.\ined(__RTP__) i]!!d.\ined(_WRS_KERNEL)Selsplay_r *zSufpas wduhpwen(;n iacuiL_ cuiL {
g }
id();n iac  re(pwen(=g }pw
id(
id)) != rned *z[++i];
hoS _dir {
pwen(->pw_dir;
LIit} }
}
qlite3
pTE_yin\ined(_WIN32_WCE)
 =/zAWiDEows CE (arm-win e-oo sw32 e-gcc)pdoe
 git.t(Svi
  g }env()Seleh  }
hoS _dir {
"/"( #g[0]mpTE_yin\ined(_WIN32) trid.\ined(WIN32)pla=' (!hoS _dir *z[++i]hoS _dir {
g }env("UlitPROlong sqlitsmqlite3
p(zTy (!hoS _dir *z[++i]hoS _dir {
g }env("HOMg sqlitsmpTE_yin\ined(_WIN32) trid.\ined(WIN32)pla=' (!hoS _dir *z[++i]  constDrivelu*zPath;n iac ;
 nrc!=  tDrive {
g }env("HOMgDRIVE>writablzPath {
g }env("HOMgPATHfErr ){
    tDrive i]! Path EstLoop =*msgery);
   rDrive) +gery);
   rPath) +g1;n iac choS _dir {
L );
 ren =SQLIitaiTE_ChoS _dirg[0riS  }
   }PAretuow(zErr); +100, zQ2z, hoS _dirns);s%s000rDrivelurPath);n iac c_ }
   hoS _dir;
 iac}sbleehoS _dir {
"c:\\"qlitsmqlite3
pqlite3 /ex!_WIN32_WCE h   reTypehoS _dir i{n iac ;
 nmsgery);
   hoS _dir *+g1;n iac  const {
L );
 ren =SQLIit    te)0psecpylt, hoS _dirnsn=SQLIithoS _dir {
zqlitsmp c_ }
   hoS _dir;
}

/*
** R a(S zse( from tnewril  givenuby (zErr)rc_ove oi
 .  Orp  itna(
**  ptimetea nsirned, oiklS zse( from ~/.(zErr)rc
**
** R }
  s tnewtes wrtefie opes.
h  4oleanVvoidet(Shell_(zErr)rcE   p){
  sqlit*p,tttttttttttttttttt/zAConfiguraiwrit
  "uh  }
 Sql;
  cons(zErr)rc_ove oi
  * /zAult teficonfigwril .irneduio useein\") fuh  t      conshoS _dir {
rned;pla Sql;
  cons(zErr)rcrepare_v2rc_ove oi
 ;     consrBuf {
}PQLIlong *in {
rned;ppla=' ((zErr)rcre= rned *z[++i]hoS _dir {
fiDE_hoS _dir(=SQLIit    hoS _dirg[0risplay_scrr, "Error: canno-- warLrom: \"%s\"\fiDE hoS sdireconay;                        " \"%s\"\urned~/.(zErr)rcorewritableS  }
  ;
 iac}sblee(zErr); ;
  i;
    writablzBuf {
ntf("EXPLAIN QUEa%s/.(zErr)rc",hoS _dir ;sblee(zErr)rcrepzBuff(p-}sblin {
f"rb")(zErr)rc,)rbewritaTE_Cinb){e3_st  reo din*is_izArrac iveri{Seleeeeut, "ANAor: cano-- Load.  Sresources from xp_col(zErr)rc)ritabl}itablt(Shell_
ot a*p,in=SQLIituf){
  in=SQLI}ita(zErr);
    frBuf)ri}

/*
** Sh
wDevailic EX to FILE valuop"wrip
h  4oleanV Sql;
  conzOp"wrip "KiB
  " ))-ter Nllllllllllllllloet close( port\io 'ter N'
     " ))-bail                stop aftea h  tromDense ope
     " ))-batch               forcedbatch I/O
     " ))-ator anllllllllllllloet close( port\io 'ator a'
     " ))-cmdsCOMMANDlllllllllru zFiCOMMANDo" befnat urnerom n din
     " ))-csv                 oet close( port\io 'asv'
     " ))-ff\n                t, "An to FILribefnat zQ2,u"wri      " ))-;
  Ilongrestlllllllrrne/t(Shell VFS dwril       " ))-[no]ff              }
   hf    nXozepe efTorepTE_yin\ined(PT;
   ENABLt_MEMSYS3) trid.\ined(PT;
   ENABLt_MEMSYS5)   " ))-hf p SIZE0           i++tefihf p fpe
memsys3 pe
memsys5orepTlite3_cr" ))-hflp                oh
wDtn"
 mest.
*      " ))-html                oet close( port\io HTML      " ))-;
Arrac iver        forced;
Arrac iverI/O
     " ))- valu               oet close( port\io ' val'
     " ))- vl;
               oet close( port\io ' vst'
     " ))- ookasi
  SIZE0N    useeN wriri stefiSZ by  stfpe
 ookasi
  ase inp->   " ))-o Fp0N              in\") fuo Fp0*)); oet io NorepTE_MIT_LOAD_EXENABLt_MULTIPLEX   " ))-o) fiplex           en%q',etnewm) fiplexpe
VFSorepTlite3_cr" ))-new valuSEP         oet close( r
wDs  ptiona. Dn\") f: '\\a'
     " ))-RING
){
  TEXT      oet t,
  ,"no s fpe
rnedu
){
 s. Dn\") f ''
     " ))-    cach  SIZE0N    useeN slotstefiSZ by  steach fpe
    fcach  ase inp->   " ))-scratch SIZE0N      useeN slotstefiSZ by  steach fpe
scratch ase inp->   " ))-s optionalSEP       oet close( ator ans  ptiona. Dn\") f: '|'
     " ))- oleniiiiiiiiiiiiiiit, "Anase in  olenibefnat zach ft);
   
     " ))-ver1);
             oh
wDPT;y daver1);

     " ))-vfsirestlllllll     useeNestlas tnewin\") fuVFSorepTE_MIT_LOAD_EXENABLt_VFSTRACE   " ))-vfsck(v r           en%q',etk(vo s efialluVFSr &zEsorepTlite3_; 4oleanVvoideut.
*();
 4h
wDetail     
t, "ANAor: canSeleeeeoUt.
*: %s [OPTIONS]Ilongrestl[LOA]_co     iCur"longrestlnsitnewnlt tefianDPT;y da
  ".dbi. Apnewdls to opei  crrni a      iCur"  itnewril  doe
 git.t(eviouslyS  ist._coluArgv0writaTE_C4h
wDetailb){e3_strr, "Error: cannoOPTIONS in lude:\n%s000rOp"wripsqlitsg[0]{e3_strr, "Error: cannoUs,etnew-hflp op"writfpe
addi"wriala    t thionorewrita}ita  it(1   }

/*
** I
  i;
   etnew4oleea    t thionCinbls t
h  4oleanVvoide FIL);
   p){
  sqlit*
  "=*z[++memset(
  "
 0  *));of(*
  "=     
  "0;port = of:\_List;
>oasecpyl
  "0;colS optiona,SEP_Ctor a, 2)ritaasecpyl
  "0;r     ptiona,SEP_Row, 2     
  "0;    H off\ 1,0zSel
  "0;  {
 Flgs 1,SHFLG_Lookasi
 ;ita(zErr);
config(PT;
   CONFIG_URI);1   fp(zErr);
config(PT;
   CONFIG_LOG, unc, Log,l
  "   fp(zErr);
config(PT;
   CONFIG_MULTITHREAD   fp(zErr);
+100, zQ2*));of(mFILP0ompt=, mFILP0ompt,"sce;\n> "   fp(zErr);
+100, zQ2*));of(textinueP0ompt=, textinueP0ompt," ))...> "   }

/*
** Olose( t,
  io tnew Sqlo EX zeatfplueS a/
aRck(vts w tra
aRcwriion.
h  TE_MIT__WIN32 4oleanVvoidet(, zBold(
Sql;
  constTw t){e3_HANDng clo }eGetStdHFILle(STD_OUTPUT_HANDng   fpCONSOLt_SCREEN_BUFFER_INFOwin\") fScrrenIzfo;tf(GetCSqlo EScrrenBufferIzfo( zIns&in\") fScrrenIzfo   fpSetCSqlo ETw tARckibute( zIn          FOREGROUND_RED|FOREGROUND_INTENSITY
  writaAIN QUEa%s   tTw t)  fpSetCSqlo ETw tARckibute( zInwin\") fScrrenIzfo.wARckibutes   }
#g[0]m4oleanVvoidet(, zBold(
Sql;
  constTw t){e3_AIN QUEao033[1mxp_033[0m   tTw t)  smqlite3
p/*
** Get tnewa is wri io anD--op"wri.  Thr
wDense ope FILEdi=t   nowa is wri
** is evailic E.
h  4oleanV 0;
  cmd)ine*op"wri_
){
 ();
 a ic,( 0;
  *argv,p zArgt     E_Ci==a icb){e3_strr, "Error: canno%s: t open missromDe is wri io xp_col             argv Ar, argv a ic- a   LIst  it(1   fp}
*   }
   argv i]  }

 zArPT;
   CDECL mFIL();
 a ic,( 0;
  *argvt      constc =rr_msg}PA= p){
  sqlit
  "zTmp
Sql;
  constI
  t che{
}PA=  zArg[0]=);
 rce{
}PA=  zArwarLInase inDbar*}PA=  zArrrneS din 1, zSel ;
 nCmdar*0;     cons*azCmdar*0; pTE_yUSt_SYSTEM_PT;
  +0!=1itaTE_C4 "off"mn_int(psourceid(), 0,
   ,OURCE_ID)!reb){e3_strr, "Error: cannoST;y daff     FILEsourcedver1);
 mismatch\n%s\n%s\n               en_int(psourceid(),  0,
   ,OURCE_ID)  LIst  it(1   fp}
Tlite3_crsetBt);ryM{
 (n din   fp(etvburror: cann0  _IONBFRTte3 /* MiklSsurew4o: caEisDunbuffereduh  }
Argv0 Quzrgv ArritaaFIL);
   &
  "   fp( din*is_izArrac iver=EisaRcy(0=SQA= /* MiklSsurewwdafavera valid signalEhFILler zarly,Dbefnat anytn"n_   ** elopei  donE.
  h  TE_MIT_LIGINT fp(ignal(LIGINT, izArrrupt_hFILler);
qlite3
pTE_MIT_LOAD_EXSHELL_DBrest_PROC
elsplay_/zAr itnewLOAD_EXSHELL_DBrest_PROCaaFcroei  d.\ined,rthwrS tlnsitnewnlt play_**tefia C-func"writt a/
will.t(Svi
  tnewnlt tefitnewis to operil .i Us play_**ttn"
  topil -Sime op"writto embedutn"
 n){
 .t(SgramX zelzrgerplay_**tapplilaiwris..h  }
  titR   voideLOAD_EXSHELL_DBrest_PROC)sqlite3_col*)  LIstLOAD_EXSHELL_DBrest_PROC)&
  ".zDbt chn ch   fpriwarLInase inDbar*}PA= smqlite3
p(z/zADo anD;
  i;
fpas utnrough tnew So FIL- value is wri io ;
 ai 
y_**ttnewnlt tefitnewis to operil ,ttnewnlt tefitnew;
  i;
  aiwritfil ,
y_**ttnewsi++tefitnewalArrna iverL );
 ihf p,
y_**tFILE newrirl;
 to FILE o zQ2,u"E.
  h    uraySi1+){
a ic
f            constritablz Quzrgv i]SQLIit    t Ar![1-'"isplay_sc    
  ".zDbt chn chg[0ri      ai* 
  ".zDbt chn ch {
zqlittttt+g[0]zErrMsg g /zAtxhells a is wrir a ed;
Arrt(eteduas PT; (oa dot-teo FILr)tFILErrMsg g **tmeaitt a/
githo s is\urnedfrom ( dinuh  }
tableSrrneS din 1,}PAretuowapnCmd s;n iac ciizSCmdar*(c );
 (azCmd )*));of(azCmd=0]w*nCmdwritably_sc    azCmd   rEstLoop = (* rr, "Error: cannoderrttease inp->writableSSSSS  it(1   fpriy_SS++;
  nRowazCmd=nCmd-1 msgzqlittttt+itabl}itabl    t  ag[1-'"iwz s;n iac='re, "off"),"-s  ptiona w   litttttric "off"),"-RING
){
  w   litttttric "off"),"-Rew val w   litttttric "off"),"-cmd w   litttEstLoop =(voidicmd)ine*op"wri_
){
 (a ic,(argv,p++iE;tf(p- rc =t  re, "off"),"-;
  fEqlitestLoop =tI
  t che{
cmd)ine*op"wri_
){
 (a ic,(argv,p++iE;tf(p- rc =t  re, "off"),"-batchfEqlitestLoop =/zAueedabasflecktfpe
batch port hereX*/
sowwdacueiavoidet(, z"n_   g g **t    t thion;
fmest.
*s (liklSfrom t(Shell_(zErr)rc)Dbefnat    g g **tw  doitnewactual t(Shello s efia is wrir lai rX zeatsesqldfpas .   g g *  }
tabl( din*is_izArrac iver=E0;tf(p- rc =t  re, "off"),"-hf pfEqlitestTE_yin\ined(PT;
   ENABLt_MEMSYS3) trid.\ined(PT;
   ENABLt_MEMSYS5)       
Sql;
  const i++PAretuow(zErr); ilu64;szH op   retueSt i++e{
cmd)ine*op"wri_
){
 (a ic,(argv,p++iE;tf(p- ;szH op 1,izArg) & 0xfft i++=SQLIitaiTE_CszH op>0x7fff0000"iwszH op 1,0x7fff0000PAretuow(zErr); config(PT;
   CONFIG_HEAP,
L );
 rz);
  zH op) iz);
  zH op, 64);
qlite3
f(p- rc =t  re, "off"),"-scratchfEqlitestLoop = ;
 n )*z;tf(p- ;szmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Csz>400000"iwszmsg400000SQLIitaiTE_Csz<2500"iwszmsg2500SQLIitainmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Cn>10"iwn 1, 0SQLIitaiTE_Cn<1te n 1, zSelece3(zErr); config(PT;
   CONFIG_SCRATCH,
L );
 rn*sz+1)  mznsn=SQLIit* 
  ".  {
 Flgs |1,SHFLG_Scratch;tf(p- rc =t  re, "off"),"-    cach fEqlitestLoop = ;
 n )*z;tf(p- ;szmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Csz>70000"iwszmsg70000SQLIitaiTE_Csz<800"iwszmsg800SQLIitainmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Cn<10"iwn 1, 0SQLIitai(zErr); config(PT;
   CONFIG_PAGECACHE,
L );
 rn*sz+1)  mznsn=SQLIit* 
  ".  {
 Flgs |1,SHFLG_P   cach ;tf(p- rc =t  re, "off"),"- ookasi
 fEqlitestLoop = ;
 n )*z;tf(p- ;szmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Csz<0"iwszmsg0SQLIitainmsgz);
 izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_Cn<0"iwn 1,0SQLIitai(zErr); config(PT;
   CONFIG_LOOKASIDE  mznsn=SQLIit* TE_Csz*ng[0riS
  ".  {
 Flgs &= ~SHFLG_Lookasi
 ;iTE_MIT_LOAD_EXENABLt_VFSTRACE   p- rc =t  re, "off"),"-vfsck(v fEqlitestLoop =titR   =rayvfsck(v _regime,tE          
Sql;
  constTk(v  *inn          
Sql;
  constOldVfsN chn          =ray(*xOu( )sqlite3_col,void*)n   iCur, ivoide*pOu(Argn          =raymiklDn\") f       =SQLIit* vfsck(v _regime,tE)Sk(v   0,z);
(* )sqlite3_col,void*))fputs,or: can1);
qlite3
TE_MIT_LOAD_EXENABLt_MULTIPLEX   p- rc =t  re, "off"),"-m) fiplexfEqlitestLoop =titR   =rayntf("EXPL) fiple ;
  i;
    sqlite3_col,);
 SQLIitai(zErr); m) fiplex ;
  i;
    0);1   qlite3
f(p- rc =t  re, "off"),"-o FpfEqlitestLoop =(zErr); ilu64;sz 1,izArg) & 0xffcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitai(zErr);
config(PT;
   CONFIG_MMAP_SIZE  mznsszE;tf(p- rc =t  re, "off"),"-vfsfEqlitestLoop =(zErr); vfsi*pVfs {
ntf("EXPvfs
 t)dfcmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIitaiTE_CpVfs EstLoop = (ntf("EXPvfs
regime,tEpVfs);1   fpriy_+g[0]zErrMsg g rr, "Error: cannon/
such VFS:zFile);
    zrgv i]writableSSS  it(1   fpriy_te3_stt = }
* ='re
  ".zDbt chn chg[0ri  TE_nMIT_LOAD_EXOENSIMEMORYDBe3_st
  ".zDbt chn ch {
":ase in:"  fpriwarLInase inDbar*a ic=i1+
#g[0]mg g rr, "Error: cano%s: t open n/
is to operil n ch specifi a    uArgv0writale  }
   1;pqlite3_crr
st
  ".clo }else ifSQA= /* Go aff  tFILE"rb"itnewis to operil t   itwalrrneyS  ists.  If tne
y_**tril  doe
 git.  istnwinlayE"rb"o s it.  This\t(evwrir emptywis to op
y_**tril s from beo s crrni ap  ia usea mistypesitnewis to open ch a is wri
y_**ttoitnewntf("Ew So FIL- valutool.
  h        achell(
  ".zDbt chn chRTtePreb){e3_stlState *&
  "
 0sqlitsmp= /* P(Shell tnew;
  i;
  aiwritfil p  itnerpei  onE.  If n/
-;
  Iop"wri
y_**ti  givenuon tnew So FILE val,
 ooktfpe
atfil pVFS dw~/.(zErr)rctFILErr**ttryttoit(Shell it.
  h    t(Shell_(zErr)rcE&
  "
tI
  t ch=SQA= /* MiklSatsesqldfpas utnrough tnew So FIL- value is wri FILEsei
y_**top"wrip.  This\sesqldfpas ui  d.lay dwu z"l aftea tnew;
  i;
  aiwri
y_**tril  is\t(ShelleLEsott a/
tnew So FIL- value is wris
will.ove oi
 
y_**tseiz"n_ri zetnew;
  i;
  aiwritfil .
  h    uraySi1+){
a ic
f            const Quzrgv i]SQLIit    t Ar![1-'"i textinueritabl    z= ag[1-'"is z+ ;urn iac  re, "off"),"-;
  fEqlitestLoop =i s;n iac}rc =t  re, "off"),"-htmlfEqlitestLoop =
  ".port = of:\_Html;tf(p- rc =t  re, "off"),"- atc"EqlitestLoop =
  ".port = of:\_List;
>op- rc =t  re, "off"),"- an fEqlitestLoop =
  ".port = of:\_Lin ;tf(p- rc =t  re, "off"),"-ator afEqlitestLoop =
  ".port = of:\_Ctor a;tf(p- rc =t  re, "off"),"-asvfEqlitestLoop =
  ".port = of:\_Csv  fpriy_asecpyl
  ".colS optiona,",",2)ritabl}rc =t  re, "off"),"-ter NfEqlitestLoop =
  ".port = of:\_Aer NSQLIitai(zErr);
+100, zQ2*));of(
  ".colS optiona),l
  ".colS optiona,itableSSSSSSSSSSSSSSSSSSSEP_U
  =SQLIitai(zErr);
+100, zQ2*));of(
  ".r     ptiona=,l
  ".r     ptiona,itableSSSSSSSSSSSSSSSSSSSEP_Resqrd)ritabl}rc =t  re, "off"),"-s  ptiona w   testLoop =(zErr); +100, zQ2*));of(
  ".colS optiona),l
  ".colS optiona,itableSSSSSSSSSSSSSSSSSSa%s  cmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIit}rc =t  re, "off"),"-Rew val w   testLoop =(zErr); +100, zQ2*));of(
  ".r     ptiona=,l
  ".r     ptiona,itableSSSSSSSSSSSSSSSSSSa%s  cmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIit}rc =t  re, "off"),"-RING
){
  w   testLoop =(zErr); +100, zQ2*));of(
  ".
ING& 0xf=,l
  ".
ING& 0xf,itableSSSSSSSSSSSSSSSSSSa%s  cmd)ine*op"wri_
){
 (a ic,argv,++iE=SQLIit}rc =t  re, "off"),"-ff    fEqlitestLoop =
  ".    H off\ 1,1SQLIit}rc =t  re, "off"),"-Roff    fEqlitestLoop =
  ".    H off\ 1,0;tf(p- rc =t  re, "off"),"-ff\nfEqlitestLoop =
  ".ff\nOn 1,1SQLIit}rc =t  re, "off"),"-eqpfEqlitestLoop =
  ".autoEQP 1,1SQLIit}rc =t  re, "off"),"-solen EqlitestLoop =
  ". olenOn =e1SQLIit}rc =t  re, "off"),"-scansolen EqlitestLoop =
  ". cansolenOn =e1SQLIit}rc =t  re, "off"),"-rr);slashfEqlitestLoop =/zAUndocu wri aw So FIL- valuop"wrin -rr);slashtLoop =**tCauses C-,"yle rr);slash e capesito be e
){
ni ap n PT; 4olee wristLoop =**tAINor */
send.  itnewLOA,izAoDPT;y d.i Us fultfpe
injecz"n_   g g **tcrazy by  st zetnewmiddl tefiPT; 4olee wris t
  "estromDend d.buggrom.   g g *  }
tabl
  ".rr);slashOn =e1SQLIit}rc =t  re, "off"),"-rrilfEqlitestLoop =bail_on_e ope =e1SQLIit}rc =t  re, "off"),"-ver1);
 EqlitestLoop =AIN QUEa%s xp_colu(zErr);
l bver1);
()  mn_int(psourceid()sqlittttt  }
   }PAretu rc =t  re, "off"),"-;
Arrac ive w   testLoop =( din*is_izArrac iver=E1SQLIit}rc =t  re, "off"),"-rrtchfEqlitestLoop =( din*is_izArrac iver=E0;tf(p- rc =t  re, "off"),"-hf pfEqlitestLoop =i s;n iac}rc =t  re, "off"),"-scratchfEqlitestLoop = +=2;tf(p- rc =t  re, "off"),"-    cach fEqlitestLoop = +=2;tf(p- rc =t  re, "off"),"- ookasi
 fEqlitestLoop = +=2;tf(p- rc =t  re, "off"),"-o FpfEqlitestLoop =i s;n iac}rc =t  re, "off"),"-vfsfEqlitestLoop =i s;nTE_MIT_LOAD_EXENABLt_VFSTRACE   p- rc =t  re, "off"),"-vfsck(v fEqlitestLoop =i s;nTlite3
TE_MIT_LOAD_EXENABLt_MULTIPLEX   p- rc =t  re, "off"),"-m) fiplexfEqlitestLoop =i s;nTlite3
f(p- rc =t  re, "off"),"-hflpfEqlitestLoop =ut.
*(1=SQLIit}rc =t  re, "off"),"-cmd w   testLoop =/zARunn to FILrit a/
fo);
wD-cmdsrirl;
FILEse ptioelytfrom  to FILr   g g **tt a/
s .slytappear on tnew So FIL- val.  This\seem  goofy.  It would   g g **tbe beizerp  iallu to FILriranD;
i** fordwrtt a/
tneytappear.  But   g g **tw*e_ }a;
i** fgoofy behavNor t
  hisonaical  topaiwbi_iny. h  Loop =  rei==a ic-1rEl }
      sqlize{
cmd)ine*op"wri_
){
 (a ic,argv,++iESQLIitaiTE_Cz   g[1. cEstLoop = (_prepdo_meta_ to FIL(tns&i  "   fpLIitaiTE_C_pr&&=bail_on_e ope iS  }
   rcql2z? 0 : rc;play_y_+g[0]zErrMsg g lState *&
  "
 0sqlitop = (_prepunc,  zQ2, 
  ".p_c -, unc,   &zErr);
 &
  "
 &rc =rr_=SQLIelecow      fp   !  rEstLoop = (* rr, "Error: canot open xp_coluree(rr_Err ){
          bail_on_e ope iS  }
   rc!  r?(_pr:, zSelece3eltrc =t  re ,!  rEstLoop = (* rr, "Error: canot open un%q',etoit(Shell PT; File);
    zErr ){
          bail_on_e ope iS  }
   rczSelece3elt fpriy_te3_sttrc =z[++i];
rr, "Error: cano%s: t open enknown;op"wrin xp_coluArgv0  zErr ){
  rr, "Error: canoUtew-hflp fpe
at vl;
efiop"wrip.orewritableS  }
  , zSelect = r  reType!rrneS din EstLoop/zARunnallue is wris
t a/
do git.begIL with 1-'"a  nf
tneytwerpese ptioe
g g **t So FIL- valu
ot as, excepl t
  "newa iToSkipue is wri wh ch fextFILs
g g **ttnewis to operil VFS .   g h  LoopuraySi++){
 Cmd
f          aiTE_CazCmd=i]   g[1. cEstLoop = (_prepdo_meta_ to FIL(azCmd=i]ns&i  "   fpLIitaiTE_C_priS  }
   rcql2z? 0 : rc;play_y_+g[0]zErrMsg g lState *&
  "
 0sqlitop = (_prepunc,  zQ2, 
  ".p_c azCmd=i]nsunc,   &zErr);
 &
  "
 &rc =rr_=SQLIelecow      fp   !  rEstLoop = (* rr, "Error: canot open xp_coluree(rr_Err ){
        }
   rc!  r?(_pr:, zSelece3eltrc =t  re ,!  rEstLoop = (* rr, "Error: canot open un%q',etoit(Shell PT;n xp_coluzSCmd=i]Err ){
        }
   rczSelece3elt fpriy_te3_stt Loopu   fzTCmdwrita+g[0]zErrMs/zARunn to FILrirecei  d from ( FILar(S zse(   g h  Loop  reo din*is_izArrac iveri{Seleeee  constHom+PAretuow  constHisonay {
}PQLIitaiT;
 nHisonayPQLIitair, "ErrSelece3eloST;y daver1);
 %s x.19p_co /e  tra-ver1);
-    */Selece3eloEg aszFi help\" t
  ut.
* hiris.\n           (zErr);
l bver1);
()  mn_int(psourceid()       ESQLIitaiTE_CwarLInase inDbaEstLoop = (AIN QUEaConneczedabasa >writableSSSt(, zBold()Sk(nsien(  z-ase in is to op>writableSSSt(, zUEa.\nUtewFi "rb"ilongrest\" basre"rb"iozeat                 "per1)scwria
  ".dbi.orewritableSt fpriy_tHom+ {
fiDE_hoS _dir(=SQLIitow     Hom+ EstLoop = (nHisonay {
ery);
   rHom+ *+g20SQLIelecow    (tHisonay {
L );
 rnHisonay))!  rEstLoop = (* (zErr); +100, zQ2zHisonaylurHisonayla%s/.(zErr)_hisonayolurHom+ zSelece3elt fpriy_te3_stow     Hisonay ){sunc,  rrne_hisonay(tHisonay);urn iac c_prept(Shell_
ot a*&
  "
 0sqlitop =     Hisonay ){         (nc,  strfl)_hisonay(100sqlitop = ((nc,  wrrr)_hisonay(tHisonay);litop = (    frHisonay);litop =te3_sttrc =z[++i];
_prept(Shell_
ot a*&
  "
 n din   fpstt = }
* set_t%q',_VFS *&
  "
 0sqlit='re
  ".forEstLoop(zErr);
c){
  
  ".fo=SQLI}ita(zErr);
    f
  ".zF   OnC){
 );u
re_